#pragma once
// anko/cap.h — capability data layout.
//
// Spec ref: §5.5 Capability Tables
//
// Handle format:
//   bits  0..31  slot index into the per-process cap table
//   bits 32..63  generation counter (revocation check)

#include "anko/types.h"
#define MIDIX_ABI_NO_COMPAT_NAMES 1
#include "midix/abi/cap.h"
#undef MIDIX_ABI_NO_COMPAT_NAMES

// ---------------------------------------------------------------------------
// Handle encoding (spec §5.5)
// ---------------------------------------------------------------------------
using CapHandle = u64;

constexpr CapHandle kNullCap = 0;

constexpr u32 cap_index(CapHandle h)      { return static_cast<u32>(h & 0xFFFF'FFFFu); }
constexpr u32 cap_generation(CapHandle h) { return static_cast<u32>(h >> 32); }
constexpr CapHandle cap_make(u32 index, u32 gen) {
    return (static_cast<u64>(gen) << 32) | index;
}

// ---------------------------------------------------------------------------
// Cap types (spec §5.5)
// ---------------------------------------------------------------------------
enum CapType : u16 {
    CAP_NULL        = 0,
    CAP_THREAD      = 1,
    CAP_PROCESS     = 2,
    CAP_PAGE        = 3,
    CAP_SHARED_RING = 4,
    CAP_DOORBELL    = 5,
    CAP_ARENA       = 6,
    CAP_NAMESERVICE = 7,
    CAP_SUPERVISOR  = 8,
    CAP_UART        = 9,
    CAP_TIMER       = 10,
    CAP_VM_ROOT     = 11,
    CAP_VM          = 12,
    CAP_VCPU        = 13,
    CAP_VM_MEMORY   = 14,
    CAP_VM_CHANNEL  = 15,
    CAP_SCHED_CONTEXT = 16,
    CAP_MMIO          = 17,  // device MMIO range object
    CAP_IRQ           = 18,  // IRQ line object
};

static_assert(static_cast<u16>(CAP_PROCESS) == static_cast<u16>(MX_CAP_PROCESS), "kernel cap type drift: PROCESS");
static_assert(static_cast<u16>(CAP_SHARED_RING) == static_cast<u16>(MX_CAP_SHARED_RING), "kernel cap type drift: SHARED_RING");
static_assert(static_cast<u16>(CAP_DOORBELL) == static_cast<u16>(MX_CAP_DOORBELL), "kernel cap type drift: DOORBELL");
static_assert(static_cast<u16>(CAP_ARENA) == static_cast<u16>(MX_CAP_ARENA), "kernel cap type drift: ARENA");
static_assert(static_cast<u16>(CAP_UART) == static_cast<u16>(MX_CAP_UART), "kernel cap type drift: UART");
static_assert(static_cast<u16>(CAP_VM_ROOT) == static_cast<u16>(MX_CAP_VM_ROOT), "kernel cap type drift: VM_ROOT");
static_assert(static_cast<u16>(CAP_SCHED_CONTEXT) == static_cast<u16>(MX_CAP_SCHED_CONTEXT), "kernel cap type drift: SCHED_CONTEXT");
static_assert(static_cast<u16>(CAP_MMIO) == static_cast<u16>(MX_CAP_MMIO), "kernel cap type drift: MMIO");
static_assert(static_cast<u16>(CAP_IRQ)  == static_cast<u16>(MX_CAP_IRQ),  "kernel cap type drift: IRQ");

// ---------------------------------------------------------------------------
// MMIO memory attribute classes (determines page-table memory type)
// ---------------------------------------------------------------------------
enum MxMmioAttr : u32 {
    MX_MMIO_DEVICE_nGnRnE = 1,  // strongly ordered (xHCI registers)
    MX_MMIO_DEVICE_nGnRE  = 2,  // device, early write ack (fw_cfg)
    MX_MMIO_NORMAL_NC     = 3,  // normal noncacheable (framebuffer pixels)
    MX_MMIO_WRITE_COMBINE = 4,  // write-combining (framebuffer if supported)
};

// Kernel object referenced by a CAP_MMIO entry.
struct MmioRange {
    PhysAddr phys_base;
    u64      size;
    u32      attr;          // MxMmioAttr — determines page table memory type
    u32      flags;
    u32      device_hint;   // DTB phandle or zero (informational)
    u32      region_index;
};

// Kernel object referenced by a CAP_IRQ entry.
struct IrqLine {
    u32 irq_id;      // SPI/LPI/MSI number
    u32 trigger;     // 0=level, 1=edge
    u32 flags;
    u32 device_hint;
    // Bound doorbell — set by SYS_IRQ_BIND_DOORBELL, initially zero.
    u64 doorbell_cap;
};

// ---------------------------------------------------------------------------
// Rights bits (spec §5.5)
// ---------------------------------------------------------------------------
enum CapRights : u32 {
    RIGHT_READ     = 1u << 0,
    RIGHT_WRITE    = 1u << 1,
    RIGHT_MAP      = 1u << 2,
    RIGHT_EXEC     = 1u << 3,
    RIGHT_NOTIFY   = 1u << 4,
    RIGHT_WAIT     = 1u << 5,
    RIGHT_DUP      = 1u << 6,
    RIGHT_SPAWN    = 1u << 7,
    RIGHT_KILL     = 1u << 8,
    RIGHT_REGISTER = 1u << 9,
    RIGHT_THREAD_CONTROL = 1u << 10,
    RIGHT_VM_CONTROL = 1u << 11,
    RIGHT_VM_MAP = 1u << 12,
    RIGHT_VM_INSPECT = 1u << 13,
    RIGHT_VM_DESTROY = 1u << 14,
    RIGHT_VCPU_CONTROL = 1u << 15,
    RIGHT_VCPU_INSPECT = 1u << 16,
    RIGHT_VM_MEMORY_MAP = 1u << 17,
    RIGHT_VM_MEMORY_INSPECT = 1u << 18,
    RIGHT_VM_CHANNEL_SEND = 1u << 19,
    RIGHT_VM_CHANNEL_RECV = 1u << 20,
    RIGHT_VM_CHANNEL_NOTIFY = 1u << 21,
    RIGHT_VM_CHANNEL_INSPECT = 1u << 22,
    RIGHT_VM_CREATE = 1u << 23,
    RIGHT_SCHED_CONTEXT_CONTROL = 1u << 24,
};

static_assert(static_cast<u32>(RIGHT_READ) == static_cast<u32>(MX_RIGHT_READ), "kernel right drift: READ");
static_assert(static_cast<u32>(RIGHT_WRITE) == static_cast<u32>(MX_RIGHT_WRITE), "kernel right drift: WRITE");
static_assert(static_cast<u32>(RIGHT_MAP) == static_cast<u32>(MX_RIGHT_MAP), "kernel right drift: MAP");
static_assert(static_cast<u32>(RIGHT_NOTIFY) == static_cast<u32>(MX_RIGHT_NOTIFY), "kernel right drift: NOTIFY");
static_assert(static_cast<u32>(RIGHT_WAIT) == static_cast<u32>(MX_RIGHT_WAIT), "kernel right drift: WAIT");
static_assert(static_cast<u32>(RIGHT_DUP) == static_cast<u32>(MX_RIGHT_DUP), "kernel right drift: DUP");
static_assert(static_cast<u32>(RIGHT_VM_CREATE) == static_cast<u32>(MX_RIGHT_VM_CREATE), "kernel right drift: VM_CREATE");

// ---------------------------------------------------------------------------
// CapEntry — one slot in the per-process capability table.
// Exact layout from spec §5.5.  Must be exactly 64 bytes.
// ---------------------------------------------------------------------------
struct CapEntry {
    void*  target;          // pointer to the kernel object (Thread*, Ring*, …)
    u32    rights_mask;     // CapRights bitmask
    u32    generation;      // matches the generation in the handle; mismatch = revoked
    u16    type_tag;        // CapType
    u16    flags;           // reserved for future use
    u8     reserved[44];
};
static_assert(sizeof(CapEntry) == 64, "CapEntry must be 64 bytes (spec §5.5)");

// ---------------------------------------------------------------------------
// Per-process cap table.
// V0: dense flat array of CapEntry[kCapTableSize].
// Lookup is O(1): extract index from handle, check generation.
// ---------------------------------------------------------------------------
constexpr u32 kCapTableSize = 1024; // spec §7: flat-table threshold; 64 KB per process

struct CapTable {
    CapEntry entries[kCapTableSize];
    u32      next_free; // bump pointer into entries[]
    u32      lock;
};

namespace cap {

void init();
CapHandle alloc(CapTable& table, CapType type, void* target, u32 rights);
CapEntry* lookup(CapTable& table, CapHandle handle, CapType expected_type);
CapEntry* lookup_any(CapTable& table, CapHandle handle);
void revoke(CapTable& table, CapHandle handle);
void revoke_target(CapTable& table, void* target);
bool reserve_slots(CapTable& table, u32 count);
CapHandle dup(CapTable& table, CapHandle src, u32 rights_mask);

} // namespace cap
