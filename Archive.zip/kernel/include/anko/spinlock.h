#pragma once

#include "anko/types.h"

namespace kernel {

struct SpinLock {
    u32 value;
};

class LockGuard {
public:
    explicit LockGuard(SpinLock& lock) : lock_(lock) {
        while (__atomic_exchange_n(&lock_.value, 1u, __ATOMIC_ACQUIRE) != 0) {
            asm volatile("yield" ::: "memory");
        }
    }

    ~LockGuard() {
        __atomic_store_n(&lock_.value, 0u, __ATOMIC_RELEASE);
    }

    LockGuard(const LockGuard&) = delete;
    LockGuard& operator=(const LockGuard&) = delete;

private:
    SpinLock& lock_;
};

} // namespace kernel
