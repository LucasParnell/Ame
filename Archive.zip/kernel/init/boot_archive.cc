// kernel/init/boot_archive.cc — DTB initrd discovery + initrd archive.
//
// V1 prefers an MXB1 bundle passed via QEMU -initrd. The legacy ustar parser is
// kept as a development fallback during the image-format migration. The same
// archive may also be embedded into anko as a fallback for direct
// QEMU/ELF boots where the DTB initrd pointer is not available.
//
// Important:
//   - If the archive comes from QEMU -initrd, it is already a boot-time physical
//     blob and can be handed to init directly.
//   - If the archive comes from the kernel-linked _binary_initrd_tar_bin_*
//     symbols, it is kernel-linked data and must be copied into page-backed
//     boot-image memory before being handed to userspace.
//
// Files used by boot are:
//   manifest.v0
//   init
//   nameservice
//   io.console
//   demo.ping
//   demo.pong
//   dango.manager
//   dango.auth_probe
//   linux/Image
//   linux/initramfs.cpio
//   linux/dango-linux.dtb
//   linux/manifest.toml

#include "anko/init.h"
#include "anko/mm.h"
#include "anko/log.h"
#include "anko/integrity.h"
#include "anko/panic.h"
#include "midix/abi/image.h"
#include "libk/string.h"
#include "libk/printf.h"
#include "anko/fdt.h"

namespace kernel::init {

namespace {

struct TarEntry {
    char name[100];
    const u8* data;
    usize size;
    u32 kind;
};

static TarEntry g_entries[32];
static u32 g_entry_count = 0;

// If init_archive() parsed an already-existing tar blob, remember it.
// For an external QEMU -initrd this can be handed to userspace directly.
// For the embedded kernel-linked fallback it must be copied into page-backed
// memory first.
static const u8* g_source_tar_base = nullptr;
static usize g_source_tar_size = 0;
static bool g_source_tar_requires_copy = false;

extern "C" {
#ifdef ANKO_BUILD_DEV
extern const u8 _binary_init_bin_start[];
extern const u8 _binary_init_bin_end[];
extern const u8 _binary_nameservice_bin_start[];
extern const u8 _binary_nameservice_bin_end[];
extern const u8 _binary_io_console_bin_start[];
extern const u8 _binary_io_console_bin_end[];
extern const u8 _binary_demo_ping_bin_start[];
extern const u8 _binary_demo_ping_bin_end[];
extern const u8 _binary_demo_pong_bin_start[];
extern const u8 _binary_demo_pong_bin_end[];
extern const u8 _binary_dango_manager_bin_start[];
extern const u8 _binary_dango_manager_bin_end[];
extern const u8 _binary_dango_auth_probe_bin_start[];
extern const u8 _binary_dango_auth_probe_bin_end[];
extern const u8 _binary_manifest_v0_bin_start[];
extern const u8 _binary_manifest_v0_bin_end[];

// Produced by kernel/CMakeLists.txt from build/initrd.tar.
extern const u8 _binary_initrd_tar_bin_start[];
extern const u8 _binary_initrd_tar_bin_end[];
#endif
}

#ifdef ANKO_BUILD_DEV
struct TarHeader {
    char name[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char chksum[8];
    char typeflag;
    char linkname[100];
    char magic[6];
    char version[2];
    char uname[32];
    char gname[32];
    char devmajor[8];
    char devminor[8];
    char prefix[155];
    char _pad[12];
};
static_assert(sizeof(TarHeader) == 512);
#endif
static_assert(__builtin_offsetof(MxBundleHeader, bundle_crc32c) == 64,
              "MXB1 CRC offset drift");

constexpr u8 kDevManifestPublicKeyId[MX_ED25519_PUBLIC_KEY_SIZE] = {
    0x09, 0xd9, 0xf8, 0xaf, 0x69, 0x75, 0x6a, 0x36,
    0x2a, 0x03, 0x5e, 0x61, 0x92, 0x5c, 0xdf, 0x99,
    0xdd, 0xd9, 0x51, 0x33, 0x67, 0x13, 0x46, 0x93,
    0x72, 0xc4, 0xa5, 0x9d, 0x0c, 0x49, 0xcb, 0xc3,
};

constexpr usize align_up(usize v, usize a) {
    return (v + (a - 1)) & ~(a - 1);
}

#ifdef ANKO_BUILD_DEV
bool block_is_zero(const u8* p, usize n) {
    for (usize i = 0; i < n; ++i) {
        if (p[i] != 0) return false;
    }
    return true;
}

usize parse_octal(const char* s, usize n) {
    usize v = 0;
    for (usize i = 0; i < n; ++i) {
        const char c = s[i];
        if (c == '\0' || c == ' ') break;
        if (c < '0' || c > '7') continue;
        v = (v << 3) + static_cast<usize>(c - '0');
    }
    return v;
}
#endif

void copy_cstr(char* dst, usize dst_len, const char* src) {
    if (!dst || dst_len == 0 || !src) return;

    usize i = 0;
    for (; i + 1 < dst_len && src[i]; ++i) {
        dst[i] = src[i];
    }
    dst[i] = '\0';
}

#ifdef ANKO_BUILD_DEV
void write_octal(char* dst, usize len, usize value) {
    if (!dst || len == 0) return;

    for (usize i = 0; i < len; ++i) dst[i] = '0';
    dst[len - 1] = '\0';

    if (len < 2) return;

    usize pos = len - 2;
    while (value && pos > 0) {
        dst[pos--] = static_cast<char>('0' + (value & 7u));
        value >>= 3;
    }
}

void add_embedded(const char* name, const u8* start, const u8* end) {
    if (!name || !start || !end || end <= start) return;
    if (g_entry_count >= 32) return;

    TarEntry& e = g_entries[g_entry_count++];
    libk::memset(e.name, 0, sizeof(e.name));

    const usize n = libk::strlen(name);
    const usize copy_n = (n < sizeof(e.name) - 1) ? n : (sizeof(e.name) - 1);
    libk::memcpy(e.name, name, copy_n);

    e.data = start;
    e.size = static_cast<usize>(end - start);
    e.kind = MX_BUNDLE_OBJECT_EXEC;
}
#endif

bool checked_add_u64(u64 a, u64 b, u64* out) {
    return !__builtin_add_overflow(a, b, out);
}

bool range_within(u64 off, u64 len, u64 total) {
    u64 end = 0;
    return checked_add_u64(off, len, &end) && end <= total;
}

bool copy_bundle_name(const u8* strings, u64 string_size, u32 name_offset, char* out, usize out_len) {
    if (!strings || !out || out_len == 0 || name_offset >= string_size) return false;
    usize i = 0;
    for (u64 pos = name_offset; pos < string_size && i + 1 < out_len; ++pos) {
        const char c = static_cast<char>(strings[pos]);
        if (c == '\0') {
            out[i] = '\0';
            return i > 0;
        }
        out[i++] = c;
    }
    if (i + 1 == out_len) {
        out[i] = '\0';
        return true;
    }
    return false;
}

bool signed_manifest_body(const u8* object, usize object_size,
                          const u8** out_body, usize* out_body_size) {
    if (!object || object_size < sizeof(MxSignedManifestHeader) ||
        !out_body || !out_body_size) return false;

    const auto* h = reinterpret_cast<const MxSignedManifestHeader*>(object);
    if (h->magic != MX_SIGNED_MANIFEST_MAGIC ||
        h->version != MX_SIGNED_MANIFEST_VERSION ||
        h->header_size < sizeof(MxSignedManifestHeader) ||
        h->hash_algorithm != MX_HASH_SHA256 ||
        h->signature_algorithm != MX_SIGNATURE_ED25519 ||
        h->public_key_id_size != MX_ED25519_PUBLIC_KEY_SIZE ||
        h->signature_size != MX_ED25519_SIGNATURE_SIZE) {
        return false;
    }
    if (!range_within(h->body_offset, h->body_size, object_size) ||
        !range_within(h->signature_offset, h->signature_size, object_size)) {
        return false;
    }

    const u8* body = object + h->body_offset;
    u8 body_hash[MX_SHA256_SIZE]{};
    integrity::sha256(body, static_cast<usize>(h->body_size), body_hash);
    if (!integrity::bytes_equal(body_hash, h->body_sha256, MX_SHA256_SIZE)) return false;
    if (!integrity::bytes_equal(h->public_key_id,
                                kDevManifestPublicKeyId,
                                MX_ED25519_PUBLIC_KEY_SIZE)) {
        return false;
    }

    // The MXM1 envelope is Ed25519-shaped and carries a real Ed25519 signature
    // generated by mxpack. The current kernel enforces the signed body hash and
    // trust-anchor id here; full curve verification belongs in this cold path
    // before MXB1 is used for non-development boot media.
    *out_body = body;
    *out_body_size = static_cast<usize>(h->body_size);
    return true;
}

bool parse_mxb_archive(const u8* base, usize size) {
    if (!base || size < sizeof(MxBundleHeader)) return false;
    const auto* h = reinterpret_cast<const MxBundleHeader*>(base);
    if (h->magic != MX_BUNDLE_MAGIC) return false;
    if (h->version != MX_BUNDLE_VERSION ||
        h->header_size < sizeof(MxBundleHeader) ||
        h->hash_algorithm != MX_HASH_SHA256 ||
        h->signature_algorithm != MX_SIGNATURE_ED25519 ||
        h->checksum_algorithm != MX_CHECKSUM_CRC32C ||
        h->object_count == 0 ||
        h->object_count > 64 ||
        h->bundle_size < sizeof(MxBundleHeader) ||
        h->bundle_size > size) {
        return false;
    }

    const u64 object_table_size = static_cast<u64>(h->object_count) * sizeof(MxBundleObject);
    if (!range_within(h->object_table_offset, object_table_size, h->bundle_size) ||
        !range_within(h->string_table_offset, h->string_table_size, h->bundle_size) ||
        !range_within(h->manifest_offset, h->manifest_size, h->bundle_size)) {
        return false;
    }
    if (integrity::crc32c_zero_field(base,
                                     static_cast<usize>(h->bundle_size),
                                     __builtin_offsetof(MxBundleHeader, bundle_crc32c),
                                     sizeof(h->bundle_crc32c)) != h->bundle_crc32c) {
        ANKO_LOG_WARN("kernel/init", "MXB1 bundle CRC mismatch");
        return false;
    }

    const u8* manifest_body = nullptr;
    usize manifest_body_size = 0;
    if (!signed_manifest_body(base + h->manifest_offset,
                              static_cast<usize>(h->manifest_size),
                              &manifest_body,
                              &manifest_body_size)) {
        ANKO_LOG_WARN("kernel/init", "MXB1 signed manifest rejected");
        return false;
    }

    const auto* objects = reinterpret_cast<const MxBundleObject*>(base + h->object_table_offset);
    const u8* strings = base + h->string_table_offset;
    for (u32 i = 0; i < h->object_count && g_entry_count < 32; ++i) {
        const MxBundleObject& obj = objects[i];
        if (!range_within(obj.offset, obj.size, h->bundle_size)) return false;

        const u8* object_data = base + obj.offset;
        if (integrity::crc32c(object_data, static_cast<usize>(obj.size)) != obj.crc32c) {
            ANKO_LOG_WARN("kernel/init", "MXB1 object CRC mismatch");
            return false;
        }
        u8 digest[MX_SHA256_SIZE]{};
        integrity::sha256(object_data, static_cast<usize>(obj.size), digest);
        if (!integrity::bytes_equal(digest, obj.sha256, MX_SHA256_SIZE)) {
            ANKO_LOG_WARN("kernel/init", "MXB1 object SHA-256 mismatch");
            return false;
        }

        TarEntry& e = g_entries[g_entry_count];
        libk::memset(e.name, 0, sizeof(e.name));
        if (!copy_bundle_name(strings, h->string_table_size,
                              obj.name_offset, e.name, sizeof(e.name))) {
            return false;
        }
        e.data = object_data;
        e.size = static_cast<usize>(obj.size);
        e.kind = obj.kind;
        if (obj.kind == MX_BUNDLE_OBJECT_MANIFEST) {
            const u8* body = nullptr;
            usize body_size = 0;
            if (!signed_manifest_body(object_data, static_cast<usize>(obj.size),
                                      &body, &body_size)) {
                return false;
            }
            e.data = body;
            e.size = body_size;
        }
        ++g_entry_count;
    }

    // Ensure the header-selected manifest object is available even if the
    // object table name changes in a future bundle.
    bool have_manifest = false;
    for (u32 i = 0; i < g_entry_count; ++i) {
        if (libk::strcmp(g_entries[i].name, "manifest.v0") == 0 ||
            libk::strcmp(g_entries[i].name, "manifest.json") == 0) {
            have_manifest = true;
            break;
        }
    }
    if (!have_manifest && g_entry_count < 32) {
        TarEntry& e = g_entries[g_entry_count++];
        copy_cstr(e.name, sizeof(e.name), "manifest.json");
        e.data = manifest_body;
        e.size = manifest_body_size;
        e.kind = MX_BUNDLE_OBJECT_MANIFEST;
    }

    ANKO_LOGF_INFO("kernel/init", "initrd MXB1 entries=%u size=%llu",
                   g_entry_count,
                   static_cast<unsigned long long>(h->bundle_size));
    return g_entry_count > 0;
}

#ifdef ANKO_BUILD_DEV
bool parse_tar_archive(const u8* base, usize size) {
    if (!base || size < 512) return false;

    usize off = 0;

    while (off + 512 <= size) {
        const u8* block = base + off;
        if (block_is_zero(block, 512)) break;

        const auto* h = reinterpret_cast<const TarHeader*>(block);
        const usize fsize = parse_octal(h->size, sizeof(h->size));
        const usize data_off = off + 512;
        const usize next_off = data_off + align_up(fsize, 512);

        if (next_off > size) {
            ANKO_LOGF_ERROR("kernel/init",
                            "initrd bad tar entry off=%llu size=%llu next=%llu total=%llu",
                            static_cast<unsigned long long>(off),
                            static_cast<unsigned long long>(fsize),
                            static_cast<unsigned long long>(next_off),
                            static_cast<unsigned long long>(size));
            return false;
        }

        if (g_entry_count < 32) {
            TarEntry& e = g_entries[g_entry_count++];
            libk::memset(e.name, 0, sizeof(e.name));

            for (usize i = 0; i < sizeof(e.name) - 1; ++i) {
                e.name[i] = h->name[i];
                if (h->name[i] == '\0') break;
            }

            e.data = base + data_off;
            e.size = fsize;
            e.kind = MX_BUNDLE_OBJECT_RESOURCE;
        }

        off = next_off;
    }

    return g_entry_count > 0;
}
#endif

bool alloc_contiguous_pages(usize pages, PhysAddr* out_base) {
    if (!out_base || pages == 0) return false;

    PhysAddr base = mm::alloc_page();
    if (!base) return false;

    PhysAddr expected = base + PAGE_SIZE;

    for (usize i = 1; i < pages; ++i) {
        PhysAddr pa = mm::alloc_page();
        if (!pa || pa != expected) {
            if (pa) mm::free_page(pa);

            for (usize j = 0; j < i; ++j) {
                mm::free_page(base + j * PAGE_SIZE);
            }

            return false;
        }

        expected += PAGE_SIZE;
    }

    *out_base = base;
    return true;
}

bool copy_source_tar_to_pages(PhysAddr* out_base, usize* out_size) {
    if (!out_base || !out_size) return false;
    if (!g_source_tar_base || g_source_tar_size == 0) return false;

    const usize alloc_size = align_up(g_source_tar_size, PAGE_SIZE);
    const usize pages = alloc_size / PAGE_SIZE;

    PhysAddr dst_phys = 0;
    if (!alloc_contiguous_pages(pages, &dst_phys)) {
        ANKO_LOGF_ERROR("kernel/init",
                        "initrd failed to allocate %llu contiguous pages for embedded archive",
                        static_cast<unsigned long long>(pages));
        return false;
    }

    auto* dst = reinterpret_cast<u8*>(dst_phys);
    libk::memset(dst, 0, alloc_size);
    libk::memcpy(dst, g_source_tar_base, g_source_tar_size);

    *out_base = dst_phys;
    *out_size = g_source_tar_size;

    ANKO_LOGF_INFO("kernel/init", "initrd copied embedded archive size=%llu pages=%llu",
                   static_cast<unsigned long long>(g_source_tar_size),
                   static_cast<unsigned long long>(pages));

    return true;
}

struct InitrdVisitorCtx {
    i64 chosen_depth = -1;
    PhysAddr initrd_start = 0;
    PhysAddr initrd_end = 0;
};

static bool initrd_begin_node(void* v, const char* name, u32 depth) {
    auto& ctx = *static_cast<InitrdVisitorCtx*>(v);
    if (depth == 1 && libk::strcmp(name, "chosen") == 0) {
        ctx.chosen_depth = static_cast<i64>(depth);
        ANKO_LOG_DEBUG("kernel/dtb", "chosen");
    }
    return true;
}

static void initrd_end_node(void* v, u32 depth) {
    auto& ctx = *static_cast<InitrdVisitorCtx*>(v);
    if (static_cast<i64>(depth) == ctx.chosen_depth) ctx.chosen_depth = -1;
}

static void initrd_prop(void* v, const char* name, const u8* data, u32 len, u32 depth) {
    auto& ctx = *static_cast<InitrdVisitorCtx*>(v);
    if (ctx.chosen_depth < 0 || static_cast<i64>(depth) != ctx.chosen_depth) return;
    if (libk::strcmp(name, "linux,initrd-start") == 0 && (len == 4 || len >= 8)) {
        ctx.initrd_start = (len == 4) ? static_cast<PhysAddr>(libk::be32(data))
                                       : libk::be64(data);
        ANKO_LOGF_DEBUG("kernel/dtb", "initrd-start len=%u", len);
    } else if (libk::strcmp(name, "linux,initrd-end") == 0 && (len == 4 || len >= 8)) {
        ctx.initrd_end = (len == 4) ? static_cast<PhysAddr>(libk::be32(data))
                                     : libk::be64(data);
        ANKO_LOGF_DEBUG("kernel/dtb", "initrd-end len=%u", len);
    }
}

} // namespace

bool discover_initrd(PhysAddr dtb_phys, PhysAddr* out_base, usize* out_size) {
    if (!dtb_phys || !out_base || !out_size) return false;

    const auto* dtb = reinterpret_cast<const u8*>(dtb_phys);
    InitrdVisitorCtx ctx;
    if (!fdt::walk(dtb, {&ctx, initrd_begin_node, initrd_end_node, initrd_prop})) {
        ANKO_LOG_WARN("kernel/dtb", "bad or malformed DTB");
        return false;
    }

    if (ctx.initrd_start == 0 || ctx.initrd_end <= ctx.initrd_start) {
        // No DTB initrd is normal for disk/U-Boot boots; callers fall back to
        // loading /ame/boot/system.mxb from the boot disk.
        return false;
    }

    *out_base = ctx.initrd_start;
    *out_size = static_cast<usize>(ctx.initrd_end - ctx.initrd_start);
    return true;
}

bool init_archive(PhysAddr initrd_base, usize initrd_size) {
    g_entry_count = 0;
    g_source_tar_base = nullptr;
    g_source_tar_size = 0;
    g_source_tar_requires_copy = false;

    if (!initrd_base || initrd_size == 0) {
#ifdef ANKO_BUILD_DEV
        const usize embedded_tar_size = static_cast<usize>(
            _binary_initrd_tar_bin_end - _binary_initrd_tar_bin_start);

        if (embedded_tar_size >= sizeof(MxBundleHeader) &&
            parse_mxb_archive(_binary_initrd_tar_bin_start, embedded_tar_size)) {
            g_source_tar_base = _binary_initrd_tar_bin_start;
            g_source_tar_size = embedded_tar_size;
            g_source_tar_requires_copy = true;

            ANKO_LOGF_INFO("kernel/init",
                           "initrd using embedded full archive entries=%u size=%llu",
                           g_entry_count,
                           static_cast<unsigned long long>(embedded_tar_size));
            return true;
        }
        g_entry_count = 0;
        if (embedded_tar_size >= sizeof(TarHeader) &&
            parse_tar_archive(_binary_initrd_tar_bin_start, embedded_tar_size)) {
            g_source_tar_base = _binary_initrd_tar_bin_start;
            g_source_tar_size = embedded_tar_size;
            g_source_tar_requires_copy = true;
            ANKO_LOGF_INFO("kernel/init",
                           "initrd using embedded ustar entries=%u size=%llu",
                           g_entry_count,
                           static_cast<unsigned long long>(embedded_tar_size));
            return true;
        }

        // Last-resort tiny embedded archive for early bring-up if initrd.tar was
        // not linked or could not be parsed. This path intentionally has no
        // linux/* artifacts.
        g_entry_count = 0;
        add_embedded("init", _binary_init_bin_start, _binary_init_bin_end);
        add_embedded("nameservice", _binary_nameservice_bin_start, _binary_nameservice_bin_end);
        add_embedded("io.console", _binary_io_console_bin_start, _binary_io_console_bin_end);
        add_embedded("demo.ping", _binary_demo_ping_bin_start, _binary_demo_ping_bin_end);
        add_embedded("demo.pong", _binary_demo_pong_bin_start, _binary_demo_pong_bin_end);
        add_embedded("dango.manager", _binary_dango_manager_bin_start, _binary_dango_manager_bin_end);
        add_embedded("dango.auth_probe", _binary_dango_auth_probe_bin_start,
                     _binary_dango_auth_probe_bin_end);
        add_embedded("manifest.v0", _binary_manifest_v0_bin_start, _binary_manifest_v0_bin_end);

        return g_entry_count > 0;
#else
        ANKO_LOG_ERROR("kernel/init", "release boot requires a signed MXB1 system bundle");
        return false;
#endif
    }

    const u8* base = reinterpret_cast<const u8*>(initrd_base);
    if (!parse_mxb_archive(base, initrd_size)) {
#ifdef ANKO_BUILD_DEV
        g_entry_count = 0;
        if (!parse_tar_archive(base, initrd_size)) return false;
#else
        panic("release initrd rejected: MXB1 parse or signature gate failed");
#endif
    }

    // External QEMU -initrd. This is already a boot-time physical blob.
    g_source_tar_base = base;
    g_source_tar_size = initrd_size;
    g_source_tar_requires_copy = false;

    return true;
}

bool archive_materialize(PhysAddr* out_base, usize* out_size) {
    if (!out_base || !out_size || g_entry_count == 0) return false;

    if (g_source_tar_base && g_source_tar_size != 0) {
        if (!g_source_tar_requires_copy) {
            *out_base = reinterpret_cast<PhysAddr>(g_source_tar_base);
            *out_size = g_source_tar_size;
            return true;
        }

        return copy_source_tar_to_pages(out_base, out_size);
    }

    // Last-resort materialization for the tiny legacy embedded service archive.
    // Do not use this path for linux/Image-sized archives.
#ifndef ANKO_BUILD_DEV
    return false;
#else
    usize total = 1024;
    for (u32 i = 0; i < g_entry_count; ++i) {
        total += 512 + align_up(g_entries[i].size, 512);
    }

    auto* blob = static_cast<u8*>(mm::heap_alloc(total, PAGE_SIZE));
    if (!blob) return false;

    libk::memset(blob, 0, total);

    usize off = 0;
    for (u32 i = 0; i < g_entry_count; ++i) {
        const TarEntry& entry = g_entries[i];

        auto* h = reinterpret_cast<TarHeader*>(blob + off);
        copy_cstr(h->name, sizeof(h->name), entry.name);
        write_octal(h->mode, sizeof(h->mode), 0644);
        write_octal(h->uid, sizeof(h->uid), 0);
        write_octal(h->gid, sizeof(h->gid), 0);
        write_octal(h->size, sizeof(h->size), entry.size);
        write_octal(h->mtime, sizeof(h->mtime), 0);

        for (char& c : h->chksum) c = ' ';
        h->typeflag = '0';
        copy_cstr(h->magic, sizeof(h->magic), "ustar");
        h->version[0] = '0';
        h->version[1] = '0';

        u32 sum = 0;
        const auto* bytes = reinterpret_cast<const u8*>(h);
        for (usize j = 0; j < sizeof(TarHeader); ++j) sum += bytes[j];

        write_octal(h->chksum, 7, sum);
        h->chksum[6] = '\0';
        h->chksum[7] = ' ';

        off += 512;
        libk::memcpy(blob + off, entry.data, entry.size);
        off += align_up(entry.size, 512);
    }

    *out_base = reinterpret_cast<PhysAddr>(blob);
    *out_size = total;
    return true;
#endif
}

bool archive_get(const char* name, const void** out_data, usize* out_size) {
    if (!name || !out_data || !out_size) return false;

    for (u32 i = 0; i < g_entry_count; ++i) {
        if (libk::strcmp(g_entries[i].name, name) == 0) {
            *out_data = g_entries[i].data;
            *out_size = g_entries[i].size;
            return true;
        }

        if (g_entries[i].name[0] == '.' &&
            g_entries[i].name[1] == '/' &&
            libk::strcmp(g_entries[i].name + 2, name) == 0) {
            *out_data = g_entries[i].data;
            *out_size = g_entries[i].size;
            return true;
        }
    }

    return false;
}

} // namespace kernel::init
