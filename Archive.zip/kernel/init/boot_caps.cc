// kernel/init/boot_caps.cc — assemble the initial capability set for init.
//
// Spec ref: §8 V0 Boot Flow (step 9), §7.1 Init

#include "anko/cap.h"
#include "anko/hw_info.h"
#include "anko/sched.h"
#include "anko/mm.h"
#include "anko/platform.h"
#include "anko/init.h"
#include "anko/vm.h"
#include "anko/ipc.h"
#include "anko/log.h"
#include "libk/printf.h"
#include "libk/string.h"

namespace drivers::fwcfg {
    bool write_ramfb(PhysAddr pixel_phys, u32 width, u32 height);
} // namespace drivers::fwcfg

namespace drivers::pci_probe {
    struct XhciInfo {
        PhysAddr bar0_phys;
        u64      bar0_size;
        u32      irq_line;
        bool     found;
    };
    XhciInfo find_xhci();
    MmioRange* alloc_xhci_mmio(const XhciInfo& info);
    IrqLine* alloc_xhci_irq(const XhciInfo& info);
} // namespace drivers::pci_probe

namespace kernel::init {

// DTB physical address — provided by arch/arm64/entry.S.
extern "C" PhysAddr g_dtb_phys;

namespace {

constexpr u32 kKernelLogRingOrder = 6;

constexpr usize align_up(usize value, usize align) {
    return (value + (align - 1)) & ~(align - 1);
}

} // namespace

void issue_boot_caps(Process& init_proc,
                     PhysAddr manifest_addr,
                     usize    manifest_size,
                     PhysAddr initrd_phys,
                     usize    initrd_size) {
    if (!init_proc.cap_table) return;

    auto* manifest = static_cast<MemoryObject*>(mm::heap_alloc(sizeof(MemoryObject), alignof(MemoryObject)));
    auto* initrd = static_cast<MemoryObject*>(mm::heap_alloc(sizeof(MemoryObject), alignof(MemoryObject)));
    if (!manifest || !initrd) return;

    const usize manifest_alloc_size = align_up(manifest_size ? manifest_size : PAGE_SIZE, PAGE_SIZE);
    const usize manifest_pages = manifest_alloc_size / PAGE_SIZE;
    const PhysAddr manifest_page = mm::alloc_pages_contiguous(manifest_pages);
    if (!manifest_page) return;
    libk::memset(reinterpret_cast<void*>(manifest_page), 0, manifest_alloc_size);
    if (manifest_addr) {
        libk::memcpy(reinterpret_cast<void*>(manifest_page),
                     reinterpret_cast<const void*>(manifest_addr),
                     manifest_size);
    }
    manifest->phys_base = manifest_page;
    manifest->size = manifest_alloc_size;

    initrd->phys_base = initrd_phys;
    initrd->size = initrd_size;

    // 1) manifest cap
    cap::alloc(*init_proc.cap_table, CAP_PAGE, manifest, RIGHT_READ | RIGHT_MAP);

    // 2) initrd cap (read-only in V0)
    cap::alloc(*init_proc.cap_table, CAP_PAGE, initrd, RIGHT_READ | RIGHT_MAP | RIGHT_DUP);

    // 3) root supervisor cap
    cap::alloc(*init_proc.cap_table, CAP_SUPERVISOR, &init_proc,
               RIGHT_READ | RIGHT_KILL | RIGHT_SPAWN | RIGHT_REGISTER | RIGHT_DUP);

    // 4) nameservice placeholder cap
    cap::alloc(*init_proc.cap_table, CAP_NAMESERVICE, &init_proc,
               RIGHT_REGISTER | RIGHT_READ | RIGHT_DUP);

    // 5) UART cap
    cap::alloc(*init_proc.cap_table, CAP_UART,
               reinterpret_cast<void*>(g_hw.console_base),
               RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_DUP);

    // 6) VM root authority. Init policy grants reduced VM authority to Dango.
    cap::alloc(*init_proc.cap_table, CAP_VM_ROOT, vm::root_object(),
               RIGHT_VM_CREATE | RIGHT_VM_INSPECT | RIGHT_DUP);

    // 7) Global log doorbell followed by one kernel log ring per supported CPU.
    Doorbell* log_db = ipc::doorbell_create_object(init_proc.pid);
    if (!log_db ||
        ipc::doorbell_cap_alloc(init_proc.pid, log_db,
                                RIGHT_NOTIFY | RIGHT_WAIT | RIGHT_DUP) == kNullCap) {
        ANKO_LOG_WARN("kernel/init", "log doorbell setup failed");
        return;
    }

    Ring* kernel_log_rings[kMaxCpus]{};
    for (u32 cpu = 0; cpu < kMaxCpus; ++cpu) {
        Ring* ring = ipc::ring_create_object(init_proc.pid, kKernelLogRingOrder, 0);
        kernel_log_rings[cpu] = ring;
        if (!ring ||
            ipc::ring_cap_alloc(init_proc.pid, ring,
                                RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_DUP) == kNullCap) {
            ANKO_LOGF_WARN("kernel/init", "kernel log ring%u setup failed", cpu);
            kernel_log_rings[cpu] = nullptr;
        }
    }
    anko::log::attach_console(kernel_log_rings, log_db, kMaxCpus);

    // 11) Framebuffer.  Two paths:
    //   T210: Hekate pre-configured TegraDC0; g_hw.t210_dc_fb_phys is the
    //         physical address of the active buffer. Map it as NORMAL_NC.
    //   QEMU: Allocate RAM, register it with ramfb via fw-cfg.
    if (g_hw.has_t210_dc) {
        // T210 path — re-use Hekate's framebuffer directly.
        const usize fb_size = static_cast<usize>(g_hw.t210_dc_fb_width) *
                              g_hw.t210_dc_fb_height * 4u;
        const usize fb_size_pages = (fb_size + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
        auto* fb_range = static_cast<MmioRange*>(
            mm::heap_alloc(sizeof(MmioRange), alignof(MmioRange)));
        if (fb_range) {
            fb_range->phys_base    = g_hw.t210_dc_fb_phys;
            fb_range->size         = fb_size_pages;
            fb_range->attr         = MX_MMIO_NORMAL_NC;
            fb_range->flags        = 0;
            fb_range->device_hint  = 0;
            fb_range->region_index = 0;
            cap::alloc(*init_proc.cap_table, CAP_MMIO, fb_range,
                       RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_DUP);
        } else {
            ANKO_LOG_WARN("kernel/init", "T210 fb_range alloc failed");
        }
    } else if (g_hw.has_fwcfg) {
        // QEMU ramfb path.
        constexpr u32 kFbWidth  = 1024;
        constexpr u32 kFbHeight = 768;
        constexpr usize kFbPages = (kFbWidth * kFbHeight * 4 + PAGE_SIZE - 1) / PAGE_SIZE;
        const PhysAddr fb_phys = mm::alloc_pages_contiguous(kFbPages);
        if (fb_phys) {
            libk::memset(reinterpret_cast<void*>(fb_phys), 0, kFbPages * PAGE_SIZE);
            const bool ramfb_ok = drivers::fwcfg::write_ramfb(fb_phys, kFbWidth, kFbHeight);
            if (!ramfb_ok) {
                ANKO_LOG_WARN("kernel/init", "ramfb init failed — framebuffer will be blank");
            }
            auto* fb_range = static_cast<MmioRange*>(
                mm::heap_alloc(sizeof(MmioRange), alignof(MmioRange)));
            if (fb_range) {
                fb_range->phys_base    = fb_phys;
                fb_range->size         = kFbPages * PAGE_SIZE;
                fb_range->attr         = MX_MMIO_NORMAL_NC;
                fb_range->flags        = 0;
                fb_range->device_hint  = 0;
                fb_range->region_index = 0;
                cap::alloc(*init_proc.cap_table, CAP_MMIO, fb_range,
                           RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_DUP);
            }
        } else {
            ANKO_LOG_WARN("kernel/init", "framebuffer RAM alloc failed");
        }
    }

    // 12..14) xHCI host controller.  Two paths:
    //   T210: T210 XUSB at 0x70090000 (xHCI-compatible, FALCON pre-loaded).
    //         No IRQ cap — polling mode, SMMU required for IOMMU setup.
    //   QEMU: PCI xHCI discovered via ECAM scan.
    if (g_hw.console_kind == ConsoleKind::Tegra16550) {
        // T210 XUSB xHCI registers.
        constexpr PhysAddr kXusbBase = 0x7009'0000ull;
        constexpr usize    kXusbSize = 0x8000u;   // 32 KiB xHCI register window
        constexpr usize kXhciDmaPages = 16;
        auto* xhci_mmio = static_cast<MmioRange*>(
            mm::heap_alloc(sizeof(MmioRange), alignof(MmioRange)));
        const PhysAddr xhci_dma_phys = mm::alloc_pages_contiguous(kXhciDmaPages);
        auto* xhci_dma = static_cast<Arena*>(
            mm::heap_alloc(sizeof(Arena), alignof(Arena)));
        if (xhci_mmio && xhci_dma_phys && xhci_dma) {
            xhci_mmio->phys_base    = kXusbBase;
            xhci_mmio->size         = kXusbSize;
            xhci_mmio->attr         = MX_MMIO_DEVICE_nGnRnE;
            xhci_mmio->flags        = 0;
            xhci_mmio->device_hint  = 0;
            xhci_mmio->region_index = 0;

            libk::memset(reinterpret_cast<void*>(xhci_dma_phys), 0,
                         kXhciDmaPages * PAGE_SIZE);
            xhci_dma->base_va   = 0;
            xhci_dma->phys_base = xhci_dma_phys;
            xhci_dma->size      = kXhciDmaPages * PAGE_SIZE;
            xhci_dma->owner_pid = init_proc.pid;
            xhci_dma->rights    = RIGHT_READ | RIGHT_WRITE;
            xhci_dma->flags     = kArenaFlagExposePhys;
            libk::memset(xhci_dma->pad, 0, sizeof(xhci_dma->pad));

            // Slot 12: xhci.mmio
            cap::alloc(*init_proc.cap_table, CAP_MMIO, xhci_mmio,
                       RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_DUP);
            // Slot 13: placeholder IRQ cap — keeps slot numbering consistent
            // with the QEMU path.  irq_id=0xFFFFFFFF signals no real IRQ;
            // the xhci driver uses polling mode via ANKO_XHCI_NORESET.
            auto* t210_irq = static_cast<IrqLine*>(
                mm::heap_alloc(sizeof(IrqLine), alignof(IrqLine)));
            if (t210_irq) {
                t210_irq->irq_id      = 0xFFFF'FFFFu; // sentinel: invalid
                t210_irq->trigger     = 0;
                t210_irq->flags       = 0;
                t210_irq->device_hint = 0;
                t210_irq->doorbell_cap = 0;
                cap::alloc(*init_proc.cap_table, CAP_IRQ, t210_irq,
                           RIGHT_READ | RIGHT_DUP);
            }
            // Slot 14: xhci.dma arena
            cap::alloc(*init_proc.cap_table, CAP_ARENA, xhci_dma,
                       RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_REGISTER | RIGHT_DUP);
        } else {
            ANKO_LOG_WARN("kernel/init", "T210 xhci cap object allocation failed");
        }
    } else if (g_hw.has_pcie) {
        // QEMU path: PCI xHCI scan.
        constexpr usize kXhciDmaPages = 16;
        const drivers::pci_probe::XhciInfo xhci = drivers::pci_probe::find_xhci();
        if (xhci.found) {
            MmioRange* xhci_mmio = drivers::pci_probe::alloc_xhci_mmio(xhci);
            IrqLine* xhci_irq    = drivers::pci_probe::alloc_xhci_irq(xhci);
            const PhysAddr xhci_dma_phys = mm::alloc_pages_contiguous(kXhciDmaPages);
            Arena* xhci_dma = static_cast<Arena*>(
                mm::heap_alloc(sizeof(Arena), alignof(Arena)));
            if (xhci_mmio && xhci_irq && xhci_dma_phys && xhci_dma) {
                libk::memset(reinterpret_cast<void*>(xhci_dma_phys), 0,
                             kXhciDmaPages * PAGE_SIZE);
                xhci_dma->base_va   = 0;
                xhci_dma->phys_base = xhci_dma_phys;
                xhci_dma->size      = kXhciDmaPages * PAGE_SIZE;
                xhci_dma->owner_pid = init_proc.pid;
                xhci_dma->rights    = RIGHT_READ | RIGHT_WRITE;
                xhci_dma->flags     = kArenaFlagExposePhys;
                libk::memset(xhci_dma->pad, 0, sizeof(xhci_dma->pad));

                cap::alloc(*init_proc.cap_table, CAP_MMIO, xhci_mmio,
                           RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_DUP);
                cap::alloc(*init_proc.cap_table, CAP_IRQ, xhci_irq,
                           RIGHT_READ | RIGHT_WRITE | RIGHT_DUP);
                cap::alloc(*init_proc.cap_table, CAP_ARENA, xhci_dma,
                           RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_REGISTER | RIGHT_DUP);
            } else {
                ANKO_LOG_WARN("kernel/init", "xhci cap object allocation failed");
            }
        }
    }

    // 15..16) Virtio-blk block device (QEMU only — T210 uses AmeFS via SATA/SD).
    if (g_hw.has_virtio_blk) {
        auto* blk_mmio = static_cast<MmioRange*>(
            mm::heap_alloc(sizeof(MmioRange), alignof(MmioRange)));
        constexpr usize kBlkDmaPages = 64;
        const PhysAddr blk_dma_phys = mm::alloc_pages_contiguous(kBlkDmaPages);
        Arena* blk_dma = static_cast<Arena*>(
            mm::heap_alloc(sizeof(Arena), alignof(Arena)));
        if (blk_mmio && blk_dma_phys && blk_dma) {
            blk_mmio->phys_base    = g_hw.virtio_base;
            blk_mmio->size         = platform::kVirtioMmioSize;
            blk_mmio->attr         = MX_MMIO_DEVICE_nGnRnE;
            blk_mmio->flags        = 0;
            blk_mmio->device_hint  = 0;
            blk_mmio->region_index = 0;

            libk::memset(reinterpret_cast<void*>(blk_dma_phys), 0,
                         kBlkDmaPages * PAGE_SIZE);
            blk_dma->base_va   = 0;
            blk_dma->phys_base = blk_dma_phys;
            blk_dma->size      = kBlkDmaPages * PAGE_SIZE;
            blk_dma->owner_pid = init_proc.pid;
            blk_dma->rights    = RIGHT_READ | RIGHT_WRITE;
            blk_dma->flags     = kArenaFlagExposePhys;
            libk::memset(blk_dma->pad, 0, sizeof(blk_dma->pad));

            cap::alloc(*init_proc.cap_table, CAP_MMIO, blk_mmio,
                       RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_DUP);
            cap::alloc(*init_proc.cap_table, CAP_ARENA, blk_dma,
                       RIGHT_READ | RIGHT_WRITE | RIGHT_MAP | RIGHT_REGISTER | RIGHT_DUP);
        } else {
            ANKO_LOG_WARN("kernel/init", "virtio-blk cap object allocation failed");
        }
    }
}

Process* spawn_image(const void* elf_data, usize elf_size, PrincipalClass principal,
                     u32 supervisor_pid, u32 flags, Thread** out_main_thread) {
    if (!elf_data || elf_size == 0) return nullptr;

    Process* p = sched::process_create(principal, supervisor_pid);
    if (!p) return nullptr;

    VmSpace space{};
    space.pgd_phys = p->ttbr0;
    space.pid = p->pid;

    const VirtAddr entry = load_image(space, elf_data, elf_size);
    if (!entry) {
        sched::process_destroy(p);
        return nullptr;
    }

    const PhysAddr stack = mm::alloc_page_for(p->pid);
    if (!stack) {
        sched::process_destroy(p);
        return nullptr;
    }
    libk::memset(reinterpret_cast<void*>(stack), 0, PAGE_SIZE);
    const VirtAddr stack_base = USER_STACK_TOP - PAGE_SIZE;
    if (!mm::vm_map_owned(space, stack_base, stack, RIGHT_READ | RIGHT_WRITE)) {
        mm::free_page_for(p->pid, stack);
        sched::process_destroy(p);
        return nullptr;
    }
    const VirtAddr sp_top = USER_STACK_TOP - 16;
    p->next_stack_slot = 1;

    const u32 thread_flags = (flags & SPAWN_SUSPENDED) ? THREAD_SUSPENDED : 0;
    Thread* t = sched::thread_create(p->pid, entry, sp_top, PRIO_SERVICE, 0, thread_flags);
    if (!t) {
        sched::process_destroy(p);
        return nullptr;
    }
    if (out_main_thread) *out_main_thread = t;
    if (!(flags & SPAWN_SUSPENDED)) sched::enqueue(t);
    return p;
}

Process* spawn_service(const char* service_name, PrincipalClass principal, u32 supervisor_pid,
                       u32 flags, Thread** out_main_thread) {
    if (!service_name) return nullptr;

    const void* blob = nullptr;
    usize blob_size = 0;
    if (!archive_get(service_name, &blob, &blob_size)) return nullptr;
    Process* p = spawn_image(blob, blob_size, principal, supervisor_pid, flags, out_main_thread);
    if (p) sched::process_set_name(p, service_name);
    return p;
}

void create_init_process() {
    PhysAddr initrd_base = 0;
    usize initrd_size = 0;

    bool archive_ready = false;
    bool embedded_archive = false;
    if (discover_initrd(g_dtb_phys, &initrd_base, &initrd_size)) {
        archive_ready = init_archive(initrd_base, initrd_size);
        if (!archive_ready) {
            ANKO_LOG_WARN("kernel/init", "initrd archive parse failed, trying embedded archive");
            initrd_base = 0;
            initrd_size = 0;
        }
    }
    if (!archive_ready) {
        if (load_system_bundle_from_disk(&initrd_base, &initrd_size)) {
            archive_ready = init_archive(initrd_base, initrd_size);
            if (!archive_ready) {
                ANKO_LOG_WARN("kernel/init", "disk system bundle rejected, trying embedded archive");
                initrd_base = 0;
                initrd_size = 0;
            }
        }
    }
    if (!archive_ready) {
        archive_ready = init_archive(0, 0);
        embedded_archive = archive_ready;
    }
    if (!archive_ready) {
        ANKO_LOG_ERROR("kernel/init", "no init archive");
        return;
    }
    if (embedded_archive && !archive_materialize(&initrd_base, &initrd_size)) {
        ANKO_LOG_ERROR("kernel/init", "embedded initrd materialize failed");
        return;
    }

    const void* manifest_blob = nullptr;
    usize manifest_size = 0;
    if (!archive_get("manifest.json", &manifest_blob, &manifest_size)) {
        if (!archive_get("manifest.v0", &manifest_blob, &manifest_size)) {
            manifest_blob = nullptr;
            manifest_size = 0;
        }
    }

    Process* init_proc = spawn_service("init", PRINCIPAL_NATIVE_TRUSTED, /*supervisor=*/0);
    if (!init_proc) {
        ANKO_LOG_ERROR("kernel/init", "spawn failed");
        return;
    }
    issue_boot_caps(*init_proc,
                    static_cast<PhysAddr>(reinterpret_cast<u64>(manifest_blob)),
                    manifest_size,
                    initrd_base,
                    initrd_size);
    ANKO_LOG_INFO("kernel/init", "init queued");
}

} // namespace kernel::init
