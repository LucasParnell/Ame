// kernel/init/elf_loader.cc — native MXI1 loader with legacy ELF fallback.
//
// Spec ref: §5.1 Boot (step 13: "load init from the boot image")
//
// Loads a statically-linked ELF64 LE AArch64 binary from the initrd
// into a new user address space. No dynamic linking, no relocation.
//
// Steps:
//   1. Validate ELF magic, class=64, data=LE, type=ET_EXEC, machine=AArch64.
//   2. Walk PT_LOAD segments; for each:
//      a. Allocate physical pages (ceil(filesz / PAGE_SIZE)).
//      b. Copy segment data from initrd.
//      c. Map pages into target VmSpace with correct rights (R/RX/RW).
//   3. Return entry point virtual address.
//
// Does not support:
//   - PIE / ET_DYN (V0 binaries are ET_EXEC at fixed VA).
//   - TLS segments.
//   - GNU stack notes.

#include "anko/init.h"
#include "anko/integrity.h"
#include "midix/abi/image.h"
#include "libk/string.h"

namespace kernel::init {

namespace {

constexpr u32 PT_LOAD = 1;
constexpr u32 PF_X = 1;
constexpr u32 PF_W = 2;
constexpr u32 PF_R = 4;
constexpr u16 ET_EXEC = 2;
constexpr u16 EM_AARCH64 = 183;
constexpr bool kAllowLegacyElfFallback = false;
constexpr usize kImageCrcOffset = 112;
constexpr u32 kMaxLoadSegments = 32;
constexpr u64 kMaxMappedImagePages = 4096;

bool checked_add(u64 a, u64 b, u64* out) {
    return !__builtin_add_overflow(a, b, out);
}

bool checked_mul(u64 a, u64 b, u64* out) {
    return !__builtin_mul_overflow(a, b, out);
}

bool range_within(u64 off, u64 size, u64 total) {
    u64 end = 0;
    return checked_add(off, size, &end) && end <= total;
}

bool align_up_u64(u64 v, u64 a, u64* out) {
    u64 rounded = 0;
    if (!checked_add(v, a - 1, &rounded)) return false;
    *out = rounded & ~(a - 1);
    return true;
}

struct SegmentPlan {
    VirtAddr va_start;
    u64 page_off;
    u64 map_size;
    u64 file_offset;
    u64 file_size;
    u32 rights;
};

bool plans_overlap(const SegmentPlan& a, const SegmentPlan& b) {
    u64 a_end = 0;
    u64 b_end = 0;
    if (!checked_add(a.va_start, a.map_size, &a_end)) return true;
    if (!checked_add(b.va_start, b.map_size, &b_end)) return true;
    return a.va_start < b_end && b.va_start < a_end;
}

void unwind_loaded(VmSpace& space, const SegmentPlan* plans, u32 count) {
    for (u32 i = 0; i < count; ++i) {
        mm::vm_unmap_owned_range(space, plans[i].va_start, plans[i].map_size);
    }
}

bool load_plan(VmSpace& space, const u8* image_data, const SegmentPlan& plan) {
    for (u64 off = 0; off < plan.map_size; off += PAGE_SIZE) {
        PhysAddr page = mm::alloc_page_for(space.pid);
        if (!page) return false;
        libk::memset(reinterpret_cast<void*>(page), 0, PAGE_SIZE);

        const u64 page_seg_start = off;
        const u64 page_seg_end = off + PAGE_SIZE;
        const u64 file_start = page_seg_start > plan.page_off ? page_seg_start - plan.page_off : 0;
        if (file_start < plan.file_size) {
            u64 file_end = page_seg_end > plan.page_off ? page_seg_end - plan.page_off : 0;
            if (file_end > plan.file_size) file_end = plan.file_size;
            if (file_end > file_start) {
                const u64 dst_off = (plan.page_off + file_start) - page_seg_start;
                const auto* src = image_data + plan.file_offset + file_start;
                libk::memcpy(reinterpret_cast<u8*>(page) + dst_off,
                             src,
                             static_cast<usize>(file_end - file_start));
            }
        }

        if (plan.rights & RIGHT_EXEC) {
            mm::sync_icache_range(page, PAGE_SIZE);
        }

        if (!mm::vm_map_owned(space, plan.va_start + off, page, plan.rights)) {
            mm::free_page_for(space.pid, page);
            mm::vm_unmap_owned_range(space, plan.va_start, off);
            return false;
        }
    }
    return true;
}

struct Elf64Ehdr {
    u8  e_ident[16];
    u16 e_type;
    u16 e_machine;
    u32 e_version;
    u64 e_entry;
    u64 e_phoff;
    u64 e_shoff;
    u32 e_flags;
    u16 e_ehsize;
    u16 e_phentsize;
    u16 e_phnum;
    u16 e_shentsize;
    u16 e_shnum;
    u16 e_shstrndx;
};

struct Elf64Phdr {
    u32 p_type;
    u32 p_flags;
    u64 p_offset;
    u64 p_vaddr;
    u64 p_paddr;
    u64 p_filesz;
    u64 p_memsz;
    u64 p_align;
};

bool check_ident(const u8* id) {
    return id[0] == 0x7F && id[1] == 'E' && id[2] == 'L' && id[3] == 'F'
        && id[4] == 2 && id[5] == 1;
}

} // namespace

static_assert(__builtin_offsetof(MxImageHeader, image_crc32c) == kImageCrcOffset,
              "MXI1 CRC offset drift");

VirtAddr load_native_image(VmSpace& space, const void* image_data, usize image_size) {
    if (!image_data || image_size < sizeof(MxImageHeader)) return 0;

    const auto* hdr = static_cast<const MxImageHeader*>(image_data);
    if (hdr->magic != MX_IMAGE_MAGIC) return 0;
    if (hdr->version != MX_IMAGE_VERSION ||
        hdr->header_size < sizeof(MxImageHeader) ||
        hdr->kind != MX_IMAGE_KIND_EXEC ||
        hdr->arch != MX_IMAGE_ARCH_AARCH64 ||
        hdr->abi_version != MX_IMAGE_ABI_VERSION) {
        return 0;
    }
    if (hdr->image_size == 0 || hdr->image_size > image_size) return 0;
    if (hdr->segment_count == 0 || hdr->segment_count > 32) return 0;
    if (hdr->import_count != 0) return 0; // V1 executes static images only.
    if (hdr->checksum_algorithm != MX_CHECKSUM_CRC32C) return 0;
    if (integrity::crc32c_zero_field(static_cast<const u8*>(image_data),
                                     static_cast<usize>(hdr->image_size),
                                     kImageCrcOffset,
                                     sizeof(hdr->image_crc32c)) != hdr->image_crc32c) {
        return 0;
    }

    const u64 seg_table_size = static_cast<u64>(hdr->segment_count) * sizeof(MxImageSegment);
    if (!range_within(hdr->segment_table_offset, seg_table_size, hdr->image_size)) return 0;
    if (hdr->requirement_count != 0) {
        const u64 req_table_size = static_cast<u64>(hdr->requirement_count) * sizeof(MxImageRequirement);
        if (!range_within(hdr->requirement_table_offset, req_table_size, hdr->image_size)) return 0;
    }
    if (hdr->string_table_size != 0 &&
        !range_within(hdr->string_table_offset, hdr->string_table_size, hdr->image_size)) {
        return 0;
    }

    const auto* segs = reinterpret_cast<const MxImageSegment*>(
        static_cast<const u8*>(image_data) + hdr->segment_table_offset);

    SegmentPlan plans[kMaxLoadSegments]{};
    u32 plan_count = 0;
    u64 mapped_pages = 0;
    bool entry_in_exec = false;
    for (u32 i = 0; i < hdr->segment_count; ++i) {
        const MxImageSegment& seg = segs[i];
        if (seg.memory_size == 0) return 0;
        if (seg.file_size > seg.memory_size) return 0;
        if (!range_within(seg.file_offset, seg.file_size, hdr->image_size)) return 0;
        if (seg.virtual_address == 0) return 0;
        if ((seg.rights & MX_RIGHT_WRITE) && (seg.rights & MX_RIGHT_EXEC)) return 0;
        if ((seg.rights & (MX_RIGHT_READ | MX_RIGHT_WRITE | MX_RIGHT_EXEC)) == 0) return 0;

        const VirtAddr va_start = static_cast<VirtAddr>(
            seg.virtual_address & ~(static_cast<u64>(PAGE_SIZE - 1)));
        const u64 page_off = seg.virtual_address - va_start;
        u64 map_size = 0;
        if (!checked_add(page_off, seg.memory_size, &map_size)) return 0;
        if (!align_up_u64(map_size, PAGE_SIZE, &map_size)) return 0;
        if (map_size == 0) return 0;
        mapped_pages += map_size / PAGE_SIZE;
        if (mapped_pages > kMaxMappedImagePages) return 0;

        u64 seg_end = 0;
        if (!checked_add(seg.virtual_address, seg.memory_size, &seg_end)) return 0;
        if ((seg.rights & MX_RIGHT_EXEC) &&
            hdr->entry_va >= seg.virtual_address &&
            hdr->entry_va < seg_end) {
            entry_in_exec = true;
        }

        if (plan_count >= kMaxLoadSegments) return 0;
        SegmentPlan& plan = plans[plan_count];
        plan.va_start = va_start;
        plan.page_off = page_off;
        plan.map_size = map_size;
        plan.file_offset = seg.file_offset;
        plan.file_size = seg.file_size;
        plan.rights = seg.rights & (MX_RIGHT_READ | MX_RIGHT_WRITE | MX_RIGHT_EXEC);
        for (u32 j = 0; j < plan_count; ++j) {
            if (plans_overlap(plans[j], plan)) return 0;
        }
        ++plan_count;
    }
    if (!entry_in_exec) return 0;

    const auto* bytes = static_cast<const u8*>(image_data);
    for (u32 i = 0; i < plan_count; ++i) {
        if (!load_plan(space, bytes, plans[i])) {
            unwind_loaded(space, plans, i);
            return 0;
        }
    }

    return static_cast<VirtAddr>(hdr->entry_va);
}

VirtAddr load_elf(VmSpace& space, const void* elf_data, usize elf_size) {
    if (!elf_data || elf_size < sizeof(Elf64Ehdr)) return 0;

    const auto* eh = static_cast<const Elf64Ehdr*>(elf_data);
    if (!check_ident(eh->e_ident)) return 0;
    if (eh->e_type != ET_EXEC || eh->e_machine != EM_AARCH64) return 0;
    if (eh->e_ehsize != sizeof(Elf64Ehdr)) return 0;
    if (eh->e_phentsize != sizeof(Elf64Phdr)) return 0;
    if (eh->e_phnum == 0 || eh->e_phnum > kMaxLoadSegments) return 0;
    u64 ph_table_size = 0;
    if (!checked_mul(static_cast<u64>(eh->e_phnum), sizeof(Elf64Phdr), &ph_table_size)) return 0;
    if (!range_within(eh->e_phoff, ph_table_size, elf_size)) return 0;

    const auto* ph = reinterpret_cast<const Elf64Phdr*>(
        static_cast<const u8*>(elf_data) + eh->e_phoff);

    SegmentPlan plans[kMaxLoadSegments]{};
    u32 plan_count = 0;
    u64 mapped_pages = 0;
    bool entry_in_exec = false;
    for (u16 i = 0; i < eh->e_phnum; ++i) {
        const Elf64Phdr& seg = ph[i];
        if (seg.p_type != PT_LOAD) continue;
        if (seg.p_memsz == 0) return 0;
        if (!range_within(seg.p_offset, seg.p_filesz, elf_size)) return 0;
        if (seg.p_memsz < seg.p_filesz) return 0;
        if (seg.p_vaddr == 0) return 0;
        if ((seg.p_flags & PF_W) && (seg.p_flags & PF_X)) return 0;

        const VirtAddr va_start = static_cast<VirtAddr>(seg.p_vaddr & ~(static_cast<u64>(PAGE_SIZE - 1)));
        const u64 page_off = seg.p_vaddr - va_start;
        u64 map_size = 0;
        if (!checked_add(page_off, seg.p_memsz, &map_size)) return 0;
        if (!align_up_u64(map_size, PAGE_SIZE, &map_size)) return 0;
        if (map_size == 0) return 0;
        mapped_pages += map_size / PAGE_SIZE;
        if (mapped_pages > kMaxMappedImagePages) return 0;

        u32 rights = 0;
        if (seg.p_flags & PF_R) rights |= RIGHT_READ;
        if (seg.p_flags & PF_W) rights |= RIGHT_WRITE;
        if (seg.p_flags & PF_X) rights |= RIGHT_EXEC;
        if (rights == 0) rights = RIGHT_READ;

        u64 seg_end = 0;
        if (!checked_add(seg.p_vaddr, seg.p_memsz, &seg_end)) return 0;
        if ((rights & RIGHT_EXEC) && eh->e_entry >= seg.p_vaddr && eh->e_entry < seg_end) {
            entry_in_exec = true;
        }

        if (plan_count >= kMaxLoadSegments) return 0;
        SegmentPlan& plan = plans[plan_count];
        plan.va_start = va_start;
        plan.page_off = page_off;
        plan.map_size = map_size;
        plan.file_offset = seg.p_offset;
        plan.file_size = seg.p_filesz;
        plan.rights = rights;
        for (u32 j = 0; j < plan_count; ++j) {
            if (plans_overlap(plans[j], plan)) return 0;
        }
        ++plan_count;
    }
    if (plan_count == 0 || !entry_in_exec) return 0;

    const auto* bytes = static_cast<const u8*>(elf_data);
    for (u32 i = 0; i < plan_count; ++i) {
        if (!load_plan(space, bytes, plans[i])) {
            unwind_loaded(space, plans, i);
            return 0;
        }
    }

    return static_cast<VirtAddr>(eh->e_entry);
}

VirtAddr load_image(VmSpace& space, const void* image_data, usize image_size) {
    if (!image_data || image_size < 4) return 0;
    const u32 magic = *static_cast<const u32*>(image_data);
    if (magic == MX_IMAGE_MAGIC) return load_native_image(space, image_data, image_size);
    if constexpr (kAllowLegacyElfFallback) return load_elf(space, image_data, image_size);
    return 0;
}

bool load_service_elf(const char* service_name, VmSpace& space, VirtAddr* out_entry) {
    if (!service_name || !out_entry) return false;
    const void* blob = nullptr;
    usize blob_size = 0;
    if (!archive_get(service_name, &blob, &blob_size)) return false;
    const VirtAddr entry = load_image(space, blob, blob_size);
    if (!entry) return false;
    *out_entry = entry;
    return true;
}

} // namespace kernel::init
