// kernel/mm/vm_space.cc — per-process address space / page table operations.
//
// Spec ref: §5.2 Memory Management, §5.3 Address Spaces
//
// AArch64 4KB page, 48-bit VA, 4-level walk (L0–L3).
// TTBR0_EL1 → user space (lower half).
// TTBR1_EL1 → kernel (upper half, set once in entry.S, never per-process).
//
// V0 operations needed:
//   vm_space_create()           — allocate PGD, return VmSpace
//   vm_map(space, va, pa, rights) — map one page
//   vm_unmap(space, va)          — unmap one page
//   vm_map_shared(space, va, pa) — map a page shared between two spaces
//   vm_space_destroy(space)      — reclaim all page-table pages

#include "anko/mm.h"
#include "anko/cap.h"
#include "anko/hw_info.h"
#include "anko/platform.h"
#include "anko/panic.h"
#include "anko/spinlock.h"
#include "libk/string.h"

extern "C" char __text_start[];
extern "C" char __kernel_end[];

namespace mm {

namespace {

constexpr u64 kUserArenaMin = 0x1000'0000ull;
constexpr u64 kUserArenaMax = 0x4000'0000ull;
constexpr u64 kBootstrapRamMapSize = 512ull * 1024ull * 1024ull;
constexpr u64 kDeviceMapSize = 0x20000;
constexpr PhysAddr kTegraDc0Base = 0x5420'0000ull;
constexpr u64 kTegraDc0MapSize = 0x40000;
constexpr PhysAddr kTegraXusbBase = 0x7009'0000ull;
constexpr u64 kTegraXusbMapSize = 0x10000;

constexpr u64 PTE_VALID = 1ull << 0;
constexpr u64 PTE_TABLE = 1ull << 1;
constexpr u64 PTE_AF = 1ull << 10;
constexpr u64 PTE_NG = 1ull << 11;
constexpr u64 PTE_AP_EL0 = 1ull << 6;
constexpr u64 PTE_AP_RO = 1ull << 7;
constexpr u64 PTE_SH_INNER = 3ull << 8;
constexpr u64 PTE_PXN = 1ull << 53;
constexpr u64 PTE_UXN = 1ull << 54;
constexpr u64 PTE_SW_OWNED = 1ull << 55;
constexpr u64 PTE_ADDR_MASK = 0x0000'FFFF'FFFF'F000ull;
constexpr u64 DESC_TABLE = PTE_VALID | PTE_TABLE;
constexpr u64 DESC_PAGE = PTE_VALID | PTE_TABLE;

constexpr u64 ATTR_NORMAL = static_cast<u64>(platform::kMairNormal) << 2;
constexpr u64 ATTR_DEVICE = static_cast<u64>(platform::kMairDevice) << 2;

static PhysAddr g_kernel_root = 0;
static kernel::SpinLock g_vm_lock{};

u64* table_ptr(PhysAddr pa) {
    return reinterpret_cast<u64*>(pa);
}

u32 level_index(VirtAddr va, u32 level) {
    const u32 shift = 39 - (level * 9);
    return static_cast<u32>((va >> shift) & 0x1FFu);
}

bool is_table_desc(u64 desc) {
    return (desc & (PTE_VALID | PTE_TABLE)) == (PTE_VALID | PTE_TABLE);
}

bool ensure_table(u64* table, u32 idx, PhysAddr* out_pa) {
    u64 desc = table[idx];
    if (is_table_desc(desc)) {
        *out_pa = desc & PTE_ADDR_MASK;
        return true;
    }
    if (desc & PTE_VALID) return false;

    PhysAddr child = alloc_page();
    if (!child) return false;
    libk::memset(reinterpret_cast<void*>(child), 0, PAGE_SIZE);
    table[idx] = (child & PTE_ADDR_MASK) | DESC_TABLE;
    *out_pa = child;
    return true;
}

u64 user_page_attrs(u32 rights) {
    const bool writable = (rights & RIGHT_WRITE) != 0;
    const bool executable = (rights & RIGHT_EXEC) != 0;
    u64 attrs = ATTR_NORMAL | PTE_AF | PTE_SH_INNER | PTE_AP_EL0 | PTE_NG | PTE_PXN;
    if (!writable) attrs |= PTE_AP_RO;
    if (!executable) attrs |= PTE_UXN;
    return attrs;
}

u64 user_device_attrs(u32 rights) {
    const bool writable = (rights & RIGHT_WRITE) != 0;
    u64 attrs = ATTR_DEVICE | PTE_AF | PTE_AP_EL0 | PTE_NG | PTE_PXN | PTE_UXN;
    if (!writable) attrs |= PTE_AP_RO;
    return attrs;
}

u64 kernel_page_attrs(bool device) {
    u64 attrs = (device ? ATTR_DEVICE : ATTR_NORMAL) | PTE_AF | PTE_UXN;
    if (!device) attrs |= PTE_SH_INNER;
    if (device) attrs |= PTE_PXN;
    return attrs;
}

bool map_page_raw(VmSpace& space, VirtAddr va, PhysAddr pa, u64 attrs) {
    if (!space.pgd_phys) return false;
    if ((va & (PAGE_SIZE - 1)) != 0 || (pa & (PAGE_SIZE - 1)) != 0) return false;
    if ((attrs & PTE_ADDR_MASK) != 0) return false;
    const bool user = (attrs & PTE_AP_EL0) != 0;
    const bool writable = (attrs & PTE_AP_RO) == 0;
    const bool executable = (attrs & PTE_UXN) == 0;
    if (user && writable && executable) return false;

    PhysAddr table_pa = space.pgd_phys;
    for (u32 level = 0; level < 3; ++level) {
        u64* table = table_ptr(table_pa);
        const u32 idx = level_index(va, level);
        if (!ensure_table(table, idx, &table_pa)) return false;
    }

    u64* l3 = table_ptr(table_pa);
    const u32 idx = level_index(va, 3);
    if (l3[idx] & PTE_VALID) return false;
    l3[idx] = (pa & PTE_ADDR_MASK) | DESC_PAGE | attrs;
    return true;
}

bool map_identity_range(VmSpace& space, PhysAddr base, u64 size, bool device) {
    const PhysAddr start = base & ~(static_cast<PhysAddr>(PAGE_SIZE - 1));
    const PhysAddr end = (base + size + PAGE_SIZE - 1) & ~(static_cast<PhysAddr>(PAGE_SIZE - 1));
    const u64 attrs = kernel_page_attrs(device);
    for (PhysAddr pa = start; pa < end; pa += PAGE_SIZE) {
        if (!map_page_raw(space, static_cast<VirtAddr>(pa), pa, attrs)) return false;
    }
    return true;
}

bool contains_range(PhysAddr outer_base, u64 outer_size, PhysAddr inner_base, u64 inner_size) {
    if (outer_size == 0 || inner_size == 0) return false;
    u64 outer_end = 0;
    u64 inner_end = 0;
    if (__builtin_add_overflow(outer_base, outer_size, &outer_end)) return false;
    if (__builtin_add_overflow(inner_base, inner_size, &inner_end)) return false;
    return inner_base >= outer_base && inner_end <= outer_end && inner_end >= inner_base;
}

bool map_identity_if_present(VmSpace& space, PhysAddr base, u64 size, bool device) {
    if (base == 0 || size == 0) return true;
    return map_identity_range(space, base, size, device);
}

bool map_bootstrap_identity(VmSpace& space) {
    const u64 ram_map_size =
        g_hw.ram_size < kBootstrapRamMapSize ? g_hw.ram_size : kBootstrapRamMapSize;
    if (!map_identity_if_present(space, g_hw.ram_base, ram_map_size, false)) return false;

    const PhysAddr kernel_base = reinterpret_cast<PhysAddr>(&__text_start[0]);
    const PhysAddr kernel_end = reinterpret_cast<PhysAddr>(&__kernel_end[0]);
    if (kernel_end > kernel_base &&
        !contains_range(g_hw.ram_base, ram_map_size, kernel_base, kernel_end - kernel_base)) {
        if (!map_identity_range(space, kernel_base, kernel_end - kernel_base, false)) return false;
    }

    if (!map_identity_if_present(space, g_hw.gic_dist_base, kDeviceMapSize, true)) return false;
    if (!contains_range(g_hw.gic_dist_base, kDeviceMapSize, g_hw.gic_cpu_base, PAGE_SIZE)) {
        if (!map_identity_if_present(space, g_hw.gic_cpu_base, PAGE_SIZE, true)) return false;
    }
    if (!map_identity_if_present(space, g_hw.console_base, PAGE_SIZE, true)) return false;

    if (g_hw.has_fwcfg &&
        !map_identity_if_present(space, g_hw.fwcfg_base, PAGE_SIZE, true)) return false;
    if (g_hw.has_virtio_blk &&
        !map_identity_if_present(space, g_hw.virtio_base, platform::kVirtioMmioSize, true)) return false;
    if (g_hw.has_pcie &&
        !map_identity_if_present(space, g_hw.ecam_base, platform::kPciEcamProbeSize, true)) return false;

    if (g_hw.console_kind == ConsoleKind::Tegra16550) {
        if (!map_identity_range(space, kTegraDc0Base, kTegraDc0MapSize, true)) return false;
        if (!map_identity_range(space, kTegraXusbBase, kTegraXusbMapSize, true)) return false;
    }

    if (g_hw.has_t210_dc) {
        const u64 fb_size = static_cast<u64>(g_hw.t210_dc_fb_width) *
                            static_cast<u64>(g_hw.t210_dc_fb_height) * 4ull;
        if (fb_size != 0 &&
            !contains_range(g_hw.ram_base, ram_map_size, g_hw.t210_dc_fb_phys, fb_size)) {
            if (!map_identity_range(space, g_hw.t210_dc_fb_phys, fb_size, false)) return false;
        }
    }

    return true;
}

void tlbi_all() {
    asm volatile(
        "dsb ishst\n"
        "tlbi vmalle1is\n"
        "dsb ish\n"
        "isb\n"
        :
        :
        : "memory");
}

} // namespace

void sync_icache_range(PhysAddr pa, usize len) {
    if (!pa || len == 0) return;

    u64 ctr = 0;
    asm volatile("mrs %0, ctr_el0" : "=r"(ctr));

    const usize dline = 4ull << ((ctr >> 16) & 0xf);
    const PhysAddr start = pa & ~(static_cast<PhysAddr>(dline - 1));
    const PhysAddr end = (pa + len + dline - 1) & ~(static_cast<PhysAddr>(dline - 1));

    // `pa` is also a valid kernel VA in this kernel's identity map. Clean the
    // bytes just copied through the data side out to PoU, then invalidate all
    // instruction caches because the same physical page will be executed via a
    // different EL0 VA.
    for (PhysAddr p = start; p < end; p += dline) {
        asm volatile("dc cvau, %0" :: "r"(p) : "memory");
    }

    asm volatile(
        "dsb ish\n"
        "ic ialluis\n"
        "dsb ish\n"
        "isb\n"
        :
        :
        : "memory");
}

namespace {

void enable_mmu(PhysAddr root) {
    constexpr u64 mair =
        (0xFFull << (platform::kMairNormal * 8)) |
        (0x00ull << (platform::kMairDevice * 8));
    constexpr u64 tcr =
        (16ull << 0) |      // T0SZ: 48-bit VA
        (1ull << 8) |       // IRGN0: WBWA
        (1ull << 10) |      // ORGN0: WBWA
        (3ull << 12) |      // SH0: inner-shareable
        (0ull << 14) |      // TG0: 4 KiB
        (2ull << 32);       // IPS: 40-bit PA, enough for QEMU virt PCI ECAM

    asm volatile(
        "msr mair_el1, %0\n"
        "msr tcr_el1, %1\n"
        "msr ttbr0_el1, %2\n"
        "isb\n"
        "tlbi vmalle1\n"
        "dsb ish\n"
        "isb\n"
        "mrs x9, sctlr_el1\n"
        "orr x9, x9, #(1 << 0)\n"
        "orr x9, x9, #(1 << 2)\n"
        "orr x9, x9, #(1 << 12)\n"
        "msr sctlr_el1, x9\n"
        "isb\n"
        :
        : "r"(mair), "r"(tcr), "r"(root)
        : "x9", "memory");
}

bool range_overlaps(u64 a_base, u64 a_end, u64 b_base, u64 b_end) {
    return a_base < b_end && a_end > b_base;
}

bool arena_range_valid(VirtAddr base, u64 size) {
    if (size == 0) return false;
    if ((base & (PAGE_SIZE - 1)) != 0) return false;
    if ((size & (PAGE_SIZE - 1)) != 0) return false;

    u64 end = 0;
    if (__builtin_add_overflow(base, size, &end)) return false;
    if (end <= base) return false;
    if (base < kUserArenaMin || end > kUserArenaMax) return false;

    const u64 kbase = reinterpret_cast<u64>(&__text_start[0]);
    const u64 kend = reinterpret_cast<u64>(&__kernel_end[0]);
    if (range_overlaps(base, end, kbase, kend)) return false;
    return true;
}

bool valid_user_rights(u32 rights, bool device) {
    if (rights == 0) return false;
    if ((rights & ~(RIGHT_READ | RIGHT_WRITE | RIGHT_EXEC)) != 0) return false;
    if ((rights & RIGHT_WRITE) && (rights & RIGHT_EXEC)) return false;
    if (device && (rights & RIGHT_EXEC)) return false;
    return true;
}

bool unmap_page_raw(VmSpace& space, VirtAddr va, bool free_owned) {
    if (!space.pgd_phys || (va & (PAGE_SIZE - 1)) != 0) return false;
    PhysAddr table_pa = space.pgd_phys;
    for (u32 level = 0; level < 3; ++level) {
        const u64 desc = table_ptr(table_pa)[level_index(va, level)];
        if (!is_table_desc(desc)) return false;
        table_pa = desc & PTE_ADDR_MASK;
    }
    u64* l3 = table_ptr(table_pa);
    const u32 idx = level_index(va, 3);
    const u64 pte = l3[idx];
    if ((pte & PTE_VALID) == 0) return false;
    l3[idx] = 0;
    if (free_owned && (pte & PTE_SW_OWNED)) {
        free_page_for(space.pid, pte & PTE_ADDR_MASK);
    }
    return true;
}

void destroy_table(VmSpace& space, PhysAddr table_pa, u32 level) {
    if (!table_pa) return;
    u64* table = table_ptr(table_pa);
    for (u32 i = 0; i < 512; ++i) {
        const u64 desc = table[i];
        if ((desc & PTE_VALID) == 0) continue;
        if (level < 3 && is_table_desc(desc)) {
            destroy_table(space, desc & PTE_ADDR_MASK, level + 1);
        } else if (level == 3 && (desc & PTE_SW_OWNED)) {
            free_page_for(space.pid, desc & PTE_ADDR_MASK);
        }
        table[i] = 0;
    }
    free_page(table_pa);
}

} // namespace

void vm_init() {
    VmSpace kernel{};
    kernel.pid = 0;
    kernel.pgd_phys = alloc_page();
    if (!kernel.pgd_phys) return;
    libk::memset(reinterpret_cast<void*>(kernel.pgd_phys), 0, PAGE_SIZE);

    if (!map_bootstrap_identity(kernel)) return;

    g_kernel_root = kernel.pgd_phys;
    enable_mmu(g_kernel_root);
}

void vm_enable_kernel() {
    if (g_kernel_root) enable_mmu(g_kernel_root);
}

VmSpace vm_space_create(u32 pid) {
    VmSpace s{};
    s.pid = pid;
    s.pgd_phys = alloc_page();
    if (s.pgd_phys) {
        libk::memset(reinterpret_cast<void*>(s.pgd_phys), 0, PAGE_SIZE);
        map_bootstrap_identity(s);
    }
    return s;
}

bool vm_map(VmSpace& space, VirtAddr va, PhysAddr pa, u32 rights) {
    if (!valid_user_rights(rights, false)) return false;
    kernel::LockGuard guard(g_vm_lock);
    const bool ok = map_page_raw(space, va, pa, user_page_attrs(rights));
    if (ok) tlbi_all();
    return ok;
}

bool vm_map_owned(VmSpace& space, VirtAddr va, PhysAddr pa, u32 rights) {
    if (!valid_user_rights(rights, false)) return false;
    kernel::LockGuard guard(g_vm_lock);
    const bool ok = map_page_raw(space, va, pa, user_page_attrs(rights) | PTE_SW_OWNED);
    if (ok) tlbi_all();
    return ok;
}

bool vm_map_range(VmSpace& space, VirtAddr va, PhysAddr pa, u64 size, u32 rights) {
    if (!valid_user_rights(rights, false)) return false;
    if (size == 0 || (va & (PAGE_SIZE - 1)) != 0 || (pa & (PAGE_SIZE - 1)) != 0) return false;
    u64 rounded = 0;
    if (__builtin_add_overflow(size, static_cast<u64>(PAGE_SIZE - 1), &rounded)) return false;
    rounded &= ~(static_cast<u64>(PAGE_SIZE - 1));
    u64 end = 0;
    if (__builtin_add_overflow(va, rounded, &end)) return false;
    kernel::LockGuard guard(g_vm_lock);
    u64 mapped = 0;
    for (u64 off = 0; off < rounded; off += PAGE_SIZE) {
        if (!map_page_raw(space, va + off, pa + off, user_page_attrs(rights))) {
            for (u64 undo = 0; undo < mapped; undo += PAGE_SIZE) {
                (void)unmap_page_raw(space, va + undo, false);
            }
            if (mapped) tlbi_all();
            return false;
        }
        mapped += PAGE_SIZE;
    }
    tlbi_all();
    return true;
}

bool vm_map_device_range(VmSpace& space, VirtAddr va, PhysAddr pa, u64 size, u32 rights) {
    if (!valid_user_rights(rights, true)) return false;
    if (size == 0 || (va & (PAGE_SIZE - 1)) != 0 || (pa & (PAGE_SIZE - 1)) != 0) return false;
    u64 rounded = 0;
    if (__builtin_add_overflow(size, static_cast<u64>(PAGE_SIZE - 1), &rounded)) return false;
    rounded &= ~(static_cast<u64>(PAGE_SIZE - 1));
    const u64 attrs = user_device_attrs(rights);
    kernel::LockGuard guard(g_vm_lock);
    u64 mapped = 0;
    for (u64 off = 0; off < rounded; off += PAGE_SIZE) {
        if (!map_page_raw(space, va + off, pa + off, attrs)) {
            for (u64 undo = 0; undo < mapped; undo += PAGE_SIZE) {
                (void)unmap_page_raw(space, va + undo, false);
            }
            if (mapped) tlbi_all();
            return false;
        }
        mapped += PAGE_SIZE;
    }
    tlbi_all();
    return true;
}

void vm_unmap(VmSpace& space, VirtAddr va) {
    kernel::LockGuard guard(g_vm_lock);
    if (unmap_page_raw(space, va, true)) tlbi_all();
}

void vm_unmap_owned_range(VmSpace& space, VirtAddr va, u64 size) {
    if (!space.pgd_phys || size == 0 || (va & (PAGE_SIZE - 1)) != 0) return;
    u64 rounded = 0;
    if (__builtin_add_overflow(size, static_cast<u64>(PAGE_SIZE - 1), &rounded)) return;
    rounded &= ~(static_cast<u64>(PAGE_SIZE - 1));
    kernel::LockGuard guard(g_vm_lock);
    bool changed = false;
    for (u64 off = 0; off < rounded; off += PAGE_SIZE) {
        changed = unmap_page_raw(space, va + off, true) || changed;
    }
    if (changed) tlbi_all();
}

void vm_space_destroy(VmSpace& space) {
    kernel::LockGuard guard(g_vm_lock);
    if (!space.pgd_phys) return;
    destroy_table(space, space.pgd_phys, 0);
    space.pgd_phys = 0;
    tlbi_all();
}

void vm_activate(PhysAddr pgd_phys) {
    if (!pgd_phys) pgd_phys = g_kernel_root;
    asm volatile(
        "dsb ishst\n"
        "msr ttbr0_el1, %0\n"
        "isb\n"
        "tlbi vmalle1is\n"
        "dsb ish\n"
        "isb\n"
        :
        : "r"(pgd_phys)
        : "memory");
}

bool user_range_mapped(const VmSpace& space, VirtAddr va, u64 size, u32 rights) {
    if (!space.pgd_phys) return false;
    if (size == 0) return true;
    u64 end = 0;
    if (__builtin_add_overflow(va, size, &end)) return false;
    if (end <= va) return false;

    const VirtAddr start = va & ~(static_cast<VirtAddr>(PAGE_SIZE - 1));
    u64 stop_u64 = 0;
    if (__builtin_add_overflow(end, static_cast<u64>(PAGE_SIZE - 1), &stop_u64)) return false;
    const VirtAddr stop = stop_u64 & ~(static_cast<VirtAddr>(PAGE_SIZE - 1));
    for (VirtAddr cur = start; cur < stop; cur += PAGE_SIZE) {
        PhysAddr table_pa = space.pgd_phys;
        for (u32 level = 0; level < 3; ++level) {
            const u64 desc = table_ptr(table_pa)[level_index(cur, level)];
            if (!is_table_desc(desc)) return false;
            table_pa = desc & PTE_ADDR_MASK;
        }
        const u64 pte = table_ptr(table_pa)[level_index(cur, 3)];
        if ((pte & PTE_VALID) == 0) return false;
        if ((pte & PTE_AP_EL0) == 0) return false;
        if ((rights & RIGHT_WRITE) && (pte & PTE_AP_RO)) return false;
        if ((rights & RIGHT_EXEC) && (pte & PTE_UXN)) return false;
    }
    return true;
}

bool user_va_to_pa(const VmSpace& space, VirtAddr va, u32 rights, PhysAddr* out_pa) {
    if (!space.pgd_phys || !out_pa) return false;

    PhysAddr table_pa = space.pgd_phys;
    for (u32 level = 0; level < 3; ++level) {
        const u64 desc = table_ptr(table_pa)[level_index(va, level)];
        if (!is_table_desc(desc)) return false;
        table_pa = desc & PTE_ADDR_MASK;
    }

    const u64 pte = table_ptr(table_pa)[level_index(va, 3)];
    if ((pte & PTE_VALID) == 0) return false;
    if ((pte & PTE_AP_EL0) == 0) return false;
    if ((rights & RIGHT_WRITE) && (pte & PTE_AP_RO)) return false;
    if ((rights & RIGHT_EXEC) && (pte & PTE_UXN)) return false;

    *out_pa = (pte & PTE_ADDR_MASK) | (va & (PAGE_SIZE - 1));
    return true;
}

bool arena_register(ArenaTable& table, VirtAddr base, PhysAddr phys_base, u64 size, u32 owner_pid,
                    u32 rights, u32 flags, u32* out_index) {
    kernel::LockGuard guard(*reinterpret_cast<kernel::SpinLock*>(&table.lock));
    if (table.count >= kArenaTableSize) return false;
    if (phys_base && (phys_base & (PAGE_SIZE - 1)) != 0) return false;
    if (base != 0) {
        if (!arena_range_valid(base, size)) return false;
    } else {
        if (size == 0 || (size & (PAGE_SIZE - 1)) != 0 || phys_base == 0) return false;
    }

    if (base != 0) {
        const u64 end = base + size;
        for (u32 i = 0; i < table.count; ++i) {
            const Arena& existing = table.entries[i];
            if (existing.size == 0 || existing.base_va == 0) continue;
            if (range_overlaps(base, end, existing.base_va, existing.base_va + existing.size)) {
                return false;
            }
        }
    }

    const u32 idx = table.count++;
    Arena& a = table.entries[idx];
    a.base_va = base;
    a.phys_base = phys_base;
    a.size = size;
    a.owner_pid = owner_pid;
    a.rights = rights;
    a.flags = flags;
    libk::memset(a.pad, 0, sizeof(a.pad));

    if (out_index) *out_index = idx;
    return true;
}

bool arena_claim_va(ArenaTable& table, Arena& arena, VirtAddr base, u64 size,
                    bool* out_new_claim) {
    kernel::LockGuard guard(*reinterpret_cast<kernel::SpinLock*>(&table.lock));
    if (out_new_claim) *out_new_claim = false;
    if (!arena_range_valid(base, size)) return false;
    if (arena.size != size) return false;

    const bool local_arena = &arena >= table.entries && &arena < table.entries + kArenaTableSize;
    if (local_arena && arena.base_va != 0) return arena.base_va == base;

    const u64 end = base + size;
    for (u32 i = 0; i < table.count; ++i) {
        const Arena& existing = table.entries[i];
        if (local_arena && &existing == &arena) continue;
        if (existing.size == 0 || existing.base_va == 0) continue;
        if (!local_arena &&
            existing.base_va == base &&
            existing.size == size &&
            existing.phys_base == arena.phys_base) {
            return true;
        }
        if (range_overlaps(base, end, existing.base_va, existing.base_va + existing.size)) {
            return false;
        }
    }

    if (local_arena) {
        arena.base_va = base;
        if (out_new_claim) *out_new_claim = true;
        return true;
    }

    if (table.count >= kArenaTableSize) return false;
    Arena& mapping = table.entries[table.count++];
    mapping.base_va = base;
    mapping.phys_base = arena.phys_base;
    mapping.size = arena.size;
    mapping.owner_pid = arena.owner_pid;
    mapping.rights = arena.rights;
    mapping.flags = arena.flags;
    libk::memset(mapping.pad, 0, sizeof(mapping.pad));
    if (out_new_claim) *out_new_claim = true;
    return true;
}

void arena_release_va(ArenaTable& table, Arena& arena, VirtAddr base) {
    kernel::LockGuard guard(*reinterpret_cast<kernel::SpinLock*>(&table.lock));
    const bool local_arena = &arena >= table.entries && &arena < table.entries + kArenaTableSize;
    if (local_arena) {
        if (arena.base_va == base) arena.base_va = 0;
        return;
    }
    for (u32 i = 0; i < table.count; ++i) {
        Arena& existing = table.entries[i];
        if (existing.base_va != base ||
            existing.phys_base != arena.phys_base ||
            existing.size != arena.size) {
            continue;
        }
        libk::memset(&existing, 0, sizeof(existing));
        while (table.count > 0 && table.entries[table.count - 1].size == 0) {
            --table.count;
        }
        return;
    }
}

void arena_unregister(ArenaTable& table, u32 index) {
    kernel::LockGuard guard(*reinterpret_cast<kernel::SpinLock*>(&table.lock));
    if (index >= table.count) return;
    libk::memset(&table.entries[index], 0, sizeof(table.entries[index]));
    while (table.count > 0 && table.entries[table.count - 1].size == 0) {
        --table.count;
    }
}

u64 vm_debug_pte(const VmSpace& space, VirtAddr va) {
    if (!space.pgd_phys) return 0;
    PhysAddr table_pa = space.pgd_phys;
    for (u32 level = 0; level < 3; ++level) {
        const u64 desc = table_ptr(table_pa)[level_index(va, level)];
        if (!is_table_desc(desc)) return desc;
        table_pa = desc & PTE_ADDR_MASK;
    }
    return table_ptr(table_pa)[level_index(va, 3)];
}

} // namespace mm
