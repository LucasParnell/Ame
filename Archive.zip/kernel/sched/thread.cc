// kernel/sched/thread.cc — thread and process lifecycle.
//
// Spec ref: §5.3 Address Spaces, §5.4 Threads and Scheduler
//
// V0: one thread per process by default.
// Thread and Process objects are allocated from the kernel heap (mm::heap_alloc).

#include "anko/sched.h"
#include "anko/ipc.h"
#include "anko/mm.h"
#include "anko/panic.h"
#include "anko/smp.h"
#include "anko/spinlock.h"
#include "libk/string.h"

namespace sched {

static u32 g_next_tid = 1;
static u32 g_next_pid = 1;
static constexpr u32 kMaxThreads = 128;
static constexpr u32 kMaxProcs = 64;
static constexpr u32 kSandboxPageQuota = 1024;
static Thread* g_threads[kMaxThreads + 1];
static Process* g_processes[kMaxProcs + 1];
static bool g_tid_reserved[kMaxThreads + 1];
static bool g_pid_reserved[kMaxProcs + 1];
static kernel::SpinLock g_lifecycle_lock{};

static u32 alloc_pid_locked() {
    for (u32 scan = 0; scan < kMaxProcs; ++scan) {
        const u32 pid = ((g_next_pid - 1 + scan) % kMaxProcs) + 1;
        if (!g_processes[pid] && !g_pid_reserved[pid]) {
            g_pid_reserved[pid] = true;
            g_next_pid = (pid % kMaxProcs) + 1;
            return pid;
        }
    }
    return 0;
}

static u32 alloc_tid_locked() {
    for (u32 scan = 0; scan < kMaxThreads; ++scan) {
        const u32 tid = ((g_next_tid - 1 + scan) % kMaxThreads) + 1;
        if (!g_threads[tid] && !g_tid_reserved[tid]) {
            g_tid_reserved[tid] = true;
            g_next_tid = (tid % kMaxThreads) + 1;
            return tid;
        }
    }
    return 0;
}

static void release_reserved_pid(u32 pid) {
    kernel::LockGuard guard(g_lifecycle_lock);
    if (pid <= kMaxProcs && !g_processes[pid]) g_pid_reserved[pid] = false;
}

static void register_process(Process* p) {
    if (!p) return;
    if (p->pid <= kMaxProcs) {
        g_processes[p->pid] = p;
        g_pid_reserved[p->pid] = false;
    }
}

static void unregister_process(Process* p) {
    if (!p) return;
    if (p->pid <= kMaxProcs) {
        g_processes[p->pid] = nullptr;
        g_pid_reserved[p->pid] = false;
    }
}

static void register_thread(Thread* t) {
    if (!t) return;
    if (t->tid <= kMaxThreads) {
        g_threads[t->tid] = t;
        g_tid_reserved[t->tid] = false;
    }
}

static void unregister_thread(Thread* t) {
    if (!t) return;
    if (t->tid <= kMaxThreads) {
        g_threads[t->tid] = nullptr;
        g_tid_reserved[t->tid] = false;
    }
}

Thread* thread_create(u32 pid, VirtAddr entry, VirtAddr sp, ThreadPriority prio,
                      u64 arg0, u32 flags) {
    Thread* t = static_cast<Thread*>(mm::slab_alloc(sizeof(Thread), alignof(Thread)));
    if (!t) return nullptr;
    libk::memset(t, 0, sizeof(*t));

    {
        kernel::LockGuard guard(g_lifecycle_lock);
        t->tid = alloc_tid_locked();
        if (t->tid == 0) {
            mm::slab_free(t, sizeof(Thread), alignof(Thread));
            return nullptr;
        }
    }
    t->pid = pid;
    t->state = (flags & THREAD_SUSPENDED) ? TS_SUSPENDED : TS_RUNNABLE_QUEUED;
    t->cpu_id = 0;
    t->affinity_mask = 0;  // 0 = any CPU
    t->home_cpu  = kInvalidCpu;
    t->last_cpu  = kInvalidCpu;
    t->heap_idx  = 0;
    t->ctx.lr = entry;
    t->ctx.sp = sp;
    t->tf.x[0] = arg0;
    t->tf.elr = entry;
    t->tf.spsr = 0;
    t->tf.sp_el0 = sp;
    t->next = nullptr;
    t->process_next = nullptr;
    t->remote_next = nullptr;
    t->waiting_doorbell = nullptr;
    t->reply_target = nullptr;

    // V2 runtime accounting — all zeroed by memset except the sentinel values above.
    t->runtime_ns           = 0;
    t->vruntime_ns          = 0;   // normalized to min_vruntime on first enqueue
    t->wake_credit_ns       = 0;
    t->last_start_ns        = 0;
    t->last_wake_ns         = 0;
    t->slice_start_ns       = 0;
    t->slice_ns             = 0;
    t->ipc_hot_until_ns     = 0;
    t->drain_quantum_start_ns = 0;
    t->handoff_deadline_ns  = 0;
    t->donated_key          = 0;
    t->in_drain_quantum     = false;
    t->has_donation         = false;
    t->on_runqueue          = false;

    // Scheduling class mapped from legacy priority.
    // Weights follow spec §7.1: IDLE=0, BATCH=512, NORMAL=1024, SERVICE=1536, INTERACTIVE=2048.
    static constexpr SchedClass kPrioClasses[PRIO_COUNT] = {
        SCHED_IDLE, SCHED_BATCH, SCHED_NORMAL, SCHED_SERVICE, SCHED_INTERACTIVE
    };
    static constexpr u32 kPrioWeights[PRIO_COUNT] = {0, 512, 1024, 1536, 2048};
    static_assert(sizeof(kPrioClasses) / sizeof(kPrioClasses[0]) == PRIO_COUNT);
    static_assert(sizeof(kPrioWeights) / sizeof(kPrioWeights[0]) == PRIO_COUNT);
    const u32 prio_idx = (prio < PRIO_COUNT) ? static_cast<u32>(prio) : static_cast<u32>(PRIO_NORMAL);
    t->sched.sched_class        = kPrioClasses[prio_idx];
    t->sched.base_priority      = static_cast<u8>(prio_idx);
    t->sched.effective_priority = static_cast<u8>(prio_idx);
    t->sched.weight             = kPrioWeights[prio_idx];
    t->sched.slice_budget_ns    = 0;

    // Latency hint remains separate from the band. SERVICE and INTERACTIVE both
    // route through SCHED_BAND_LATENCY, but IPC servers get a tighter wake-credit
    // contract than ordinary interactive work.
    switch (prio_idx) {
    case PRIO_SERVICE:  t->latency_hint = LATENCY_IPC_SERVER;  break;
    case PRIO_CRITICAL: t->latency_hint = LATENCY_INTERACTIVE; break;
    case PRIO_BACKGROUND: t->latency_hint = LATENCY_BATCH;     break;
    default:           t->latency_hint = LATENCY_NORMAL;      break;
    }

    Process* p = find_process(pid);
    if (p) {
        t->principal_id = p->principal_id;
        t->sched_context_id = 0;
        t->sched_context = nullptr;
        t->process_next = p->threads;
        p->threads = t;
    } else {
        t->principal_id = 0;
    }

    {
        kernel::LockGuard guard(g_lifecycle_lock);
        register_thread(t);
    }
    return t;
}

void thread_destroy(Thread* t) {
    if (!t) return;
    // Unlink from owning process's thread list to prevent double-destroy.
    bool unlinked = false;
    Process* owner = find_process(t->pid);
    bool destroy_owner = false;
    if (Process* p = owner) {
        Thread** prev = &p->threads;
        while (*prev && *prev != t) prev = &(*prev)->process_next;
        if (*prev) {
            *prev = t->process_next;
            unlinked = true;
        }
        ANKO_ASSERT(unlinked);
        destroy_owner = (p->threads == nullptr && p->dying != 2);
    }
    ipc::doorbell_clear_waiter(t);
    dequeue_thread(t);  // remove from fair queue before marking dead
    t->state = TS_DEAD;
    sweep_process_caps(t);
    {
        kernel::LockGuard guard(g_lifecycle_lock);
        unregister_thread(t);
    }
    if (t != current()) {
        mm::slab_free(t, sizeof(Thread), alignof(Thread));
    }
    if (destroy_owner) {
        process_destroy(owner);
    }
}

Process* process_create(PrincipalClass principal, u32 supervisor_pid) {
    Process* p = static_cast<Process*>(mm::slab_alloc(sizeof(Process), alignof(Process)));
    if (!p) return nullptr;
    libk::memset(p, 0, sizeof(*p));

    {
        kernel::LockGuard guard(g_lifecycle_lock);
        p->pid = alloc_pid_locked();
        if (p->pid == 0) {
            mm::slab_free(p, sizeof(Process), alignof(Process));
            return nullptr;
        }
    }
    p->principal_class = principal;
    p->supervisor_pid = supervisor_pid;
    if (principal == PRINCIPAL_KERNEL) {
        p->principal_id = 0;
    } else {
        p->principal_id = allocate_principal(principal,
                                             principal == PRINCIPAL_NATIVE_TRUSTED ? 2048 : NICE_0_WEIGHT,
                                             0, 0);
        if (p->principal_id == 0) {
            release_reserved_pid(p->pid);
            mm::slab_free(p, sizeof(Process), alignof(Process));
            return nullptr;
        }
    }
    p->next_stack_slot = 0;
    p->runtime_ns = 0;
    p->page_count = 0;
    p->page_quota = (principal == PRINCIPAL_NATIVE_SANDBOXED) ? kSandboxPageQuota : 0;
    p->runnable_threads = 0;

    VmSpace vm = mm::vm_space_create(p->pid);
    if (!vm.pgd_phys) {
        release_principal(p->principal_id);
        release_reserved_pid(p->pid);
        mm::slab_free(p, sizeof(Process), alignof(Process));
        return nullptr;
    }
    p->ttbr0 = vm.pgd_phys;

    p->cap_table = static_cast<CapTable*>(mm::slab_alloc(sizeof(CapTable), alignof(CapTable)));
    if (!p->cap_table) {
        mm::vm_space_destroy(vm);
        release_principal(p->principal_id);
        release_reserved_pid(p->pid);
        mm::slab_free(p, sizeof(Process), alignof(Process));
        return nullptr;
    }
    libk::memset(p->cap_table, 0, sizeof(CapTable));
    p->cap_table->next_free = 0;

    // Initialize generations to non-zero so handle 0 is never treated as valid.
    for (u32 i = 0; i < kCapTableSize; ++i) {
        p->cap_table->entries[i].generation = 1;
        p->cap_table->entries[i].type_tag = CAP_NULL;
    }

    p->arena_table = static_cast<ArenaTable*>(
        mm::slab_alloc(sizeof(ArenaTable), alignof(ArenaTable)));
    if (!p->arena_table) {
        mm::slab_free(p->cap_table, sizeof(CapTable), alignof(CapTable));
        mm::vm_space_destroy(vm);
        release_principal(p->principal_id);
        release_reserved_pid(p->pid);
        mm::slab_free(p, sizeof(Process), alignof(Process));
        return nullptr;
    }
    libk::memset(p->arena_table, 0, sizeof(ArenaTable));

    {
        kernel::LockGuard guard(g_lifecycle_lock);
        register_process(p);
    }
    return p;
}

void process_destroy(Process* p) {
    if (!p) return;
    u32 dying = __atomic_load_n(&p->dying, __ATOMIC_ACQUIRE);
    if (dying == 2) return;
    if (dying == 0 && !__atomic_compare_exchange_n(&p->dying, &dying, 1u, false,
                                                   __ATOMIC_ACQ_REL,
                                                   __ATOMIC_ACQUIRE)) {
        if (dying == 2) return;
    }

    sweep_process_caps(p);
    bool has_remote_running_thread = false;
    for (Thread* scan = p->threads; scan; scan = scan->process_next) {
        if (scan->state == TS_RUNNING && scan != current()) {
            scan->state = TS_DEAD;
            smp::send_wake_ipi(scan->cpu_id);
            has_remote_running_thread = true;
        }
    }
    if (!has_remote_running_thread) {
        __atomic_store_n(&p->dying, 2u, __ATOMIC_RELEASE);
    }

    Thread* t = p->threads;
    while (t) {
        Thread* next = t->process_next;
        if (!(t->state == TS_RUNNING && t != current())) {
            thread_destroy(t);
        }
        t = next;
    }
    if (has_remote_running_thread) return;
    p->threads = nullptr;

    VmSpace vm{};
    vm.pgd_phys = p->ttbr0;
    vm.pid = p->pid;
    mm::vm_space_destroy(vm);
    p->ttbr0 = 0;

    {
        kernel::LockGuard guard(g_lifecycle_lock);
        unregister_process(p);
    }
    if (p->cap_table) {
        mm::slab_free(p->cap_table, sizeof(CapTable), alignof(CapTable));
        p->cap_table = nullptr;
    }
    if (p->arena_table) {
        mm::slab_free(p->arena_table, sizeof(ArenaTable), alignof(ArenaTable));
        p->arena_table = nullptr;
    }
    release_principal(p->principal_id);
    if (p != current_process()) {
        mm::slab_free(p, sizeof(Process), alignof(Process));
    }
}

void process_set_name(Process* p, const char* name) {
    if (!p || !name) return;
    usize len = libk::strlen(name);
    if (len >= sizeof(p->name)) len = sizeof(p->name) - 1;
    libk::memcpy(p->name, name, len);
    p->name[len] = '\0';
}

bool process_charge_page(u32 pid) {
    Process* p = find_process(pid);
    if (!p) return true;
    u32 count = __atomic_load_n(&p->page_count, __ATOMIC_RELAXED);
    while (true) {
        if (p->page_quota != 0 && count >= p->page_quota) return false;
        const u32 next = count + 1;
        if (__atomic_compare_exchange_n(&p->page_count, &count, next, false,
                                        __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
            return true;
        }
    }
}

void process_uncharge_page(u32 pid) {
    Process* p = find_process(pid);
    if (!p) return;
    u32 count = __atomic_load_n(&p->page_count, __ATOMIC_RELAXED);
    while (count != 0) {
        const u32 next = count - 1;
        if (__atomic_compare_exchange_n(&p->page_count, &count, next, false,
                                        __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
            return;
        }
    }
}

Thread* find_thread(u32 tid) {
    if (tid == 0 || tid > kMaxThreads) return nullptr;
    return g_threads[tid];
}

Process* find_process(u32 pid) {
    if (pid == 0 || pid > kMaxProcs) return nullptr;
    return g_processes[pid];
}

void sweep_process_caps(void* target) {
    if (!target) return;
    for (u32 i = 1; i <= kMaxProcs; ++i) {
        Process* p = g_processes[i];
        if (!p || !p->cap_table) continue;
        cap::revoke_target(*p->cap_table, target);
    }
}

} // namespace sched
