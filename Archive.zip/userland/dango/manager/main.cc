// userland/dango/manager/main.cc — Dango VM manager scaffold test.

#include "mochi/syscall.h"
#include "mochi/ring.h"
#include "mochi/log.h"
#include "dango/vm.h"
#include "dango/channel.h"
#include "dango/layout.h"

constexpr uint32_t kRingOrder = 6;
constexpr uint64_t kLinuxRunBudgetNs = 6ull * 1000ull * 1000ull;
constexpr uint64_t kLinuxRunPeriodNs = 16666667ull;
constexpr uint32_t kLinuxRunMaxExits = 512;
constexpr uint64_t kVaConsoleRing = 0x2000'0000ull;
constexpr uint64_t kVaBootInitrd = 0x2400'0000ull;
constexpr uint64_t kInitrdScanLimit = 64ull * 1024ull * 1024ull;
constexpr CapHandle cap_slot(uint32_t idx) {
    return (static_cast<CapHandle>(1) << 32) | idx;
}

constexpr CapHandle kConsoleRing = cap_slot(0);
constexpr CapHandle kConsoleDoorbell = cap_slot(1);
constexpr CapHandle kVmRoot = cap_slot(2);
constexpr CapHandle kDoneDoorbell = cap_slot(3);
constexpr CapHandle kAuthGateDoorbell = cap_slot(4);
constexpr CapHandle kLayoutDoneDoorbell = cap_slot(5);
constexpr CapHandle kBootInitrd = cap_slot(6);

struct TarHeader {
    char name[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char checksum[8];
    char typeflag;
    char linkname[100];
    char magic[6];
    char version[2];
    char uname[32];
    char gname[32];
    char devmajor[8];
    char devminor[8];
    char prefix[155];
    char pad[12];
};
static_assert(sizeof(TarHeader) == 512);

struct LinuxArtifacts {
    const uint8_t* manifest;
    uint64_t manifest_size;
    const uint8_t* image;
    uint64_t image_size;
    const uint8_t* initramfs;
    uint64_t initramfs_size;
    const uint8_t* dtb;
    uint64_t dtb_size;
    dango::VmLayout layout;
    uint64_t entry;
};

static uint32_t slen(const char* s) {
    uint32_t n = 0;
    while (s[n]) ++n;
    return n;
}

static CapHandle as_cap(int64_t v) {
    return v > 0 ? static_cast<CapHandle>(v) : kNullCap;
}

template <typename T>
static T* wait_map(CapHandle cap, int64_t expected_type, uint64_t va, uint32_t rights) {
    while (true) {
        if (sys_cap_identify(cap) == expected_type) {
            if (sys_map_page(cap, va, rights) == 0) return reinterpret_cast<T*>(va);
        }
        sys_yield();
    }
}

static void wait_cap(CapHandle cap, int64_t expected_type) {
    while (sys_cap_identify(cap) != expected_type) {
        sys_yield();
    }
}

static void console_log(const char* msg) {
    mochi::log_raw_marker(msg);
}

static void dango_log(const char* msg) {
    mochi::log_write(mochi::LogLevel::Info, msg);
}

static void dango_debug(const char* msg) {
    (void)msg;
}

[[noreturn]] static void fail(const char* msg) {
    // Keep failures visible even if the console service is blocked.
    sys_debug_puts(msg, slen(msg));
    console_log(msg);
    while (true) sys_yield();
}

static bool aligned(uint64_t v) {
    return (v & (dango::kPageSize - 1)) == 0;
}

static bool checked_add(uint64_t a, uint64_t b, uint64_t* out) {
    const uint64_t r = a + b;
    if (r < a) return false;
    *out = r;
    return true;
}

static uint64_t round_up_page(uint64_t value) {
    return (value + dango::kPageSize - 1) & ~(dango::kPageSize - 1);
}

static bool overlaps(uint64_t a_base, uint64_t a_size, uint64_t b_base, uint64_t b_size) {
    uint64_t a_end = 0;
    uint64_t b_end = 0;
    if (!checked_add(a_base, a_size, &a_end)) return true;
    if (!checked_add(b_base, b_size, &b_end)) return true;
    return a_base < b_end && a_end > b_base;
}

static bool contains(uint64_t outer_base, uint64_t outer_size,
                     uint64_t inner_base, uint64_t inner_size) {
    uint64_t outer_end = 0;
    uint64_t inner_end = 0;
    if (!checked_add(outer_base, outer_size, &outer_end)) return false;
    if (!checked_add(inner_base, inner_size, &inner_end)) return false;
    return inner_base >= outer_base && inner_end <= outer_end && inner_end >= inner_base;
}

static bool validate_layout(const dango::VmLayout& layout) {
    if (!aligned(layout.ram_base) || !aligned(layout.ram_size)) return false;
    if (!aligned(layout.kernel_load) || !aligned(layout.initramfs_load)) return false;
    if (!aligned(layout.dtb_base) || !aligned(layout.dtb_size)) return false;
    if (!aligned(layout.mmio_base) || !aligned(layout.mmio_size)) return false;
    if (!aligned(layout.channel_base) || !aligned(layout.channel_size)) return false;
    if (layout.ram_size == 0 || layout.channel_size == 0) return false;
    if (!contains(layout.ram_base, layout.ram_size, layout.kernel_load, dango::kPageSize)) return false;
    if (!contains(layout.ram_base, layout.ram_size, layout.initramfs_load, dango::kPageSize)) return false;
    if (!contains(layout.ram_base, layout.ram_size, layout.dtb_base, layout.dtb_size)) return false;
    if (!contains(layout.ram_base, layout.ram_size, layout.channel_base, layout.channel_size)) return false;
    if (overlaps(layout.ram_base, layout.ram_size, layout.mmio_base, layout.mmio_size)) return false;
    if (overlaps(layout.dtb_base, layout.dtb_size, layout.mmio_base, layout.mmio_size)) return false;
    if (overlaps(layout.dtb_base, layout.dtb_size, layout.channel_base, layout.channel_size)) return false;
    if (overlaps(layout.mmio_base, layout.mmio_size, layout.channel_base, layout.channel_size)) return false;
    return true;
}

static bool block_zero(const uint8_t* data) {
    for (uint32_t i = 0; i < 512; ++i) {
        if (data[i] != 0) return false;
    }
    return true;
}

static uint64_t octal_value(const char* s, uint32_t len) {
    uint64_t value = 0;
    for (uint32_t i = 0; i < len; ++i) {
        const char c = s[i];
        if (c == '\0' || c == ' ') break;
        if (c < '0' || c > '7') continue;
        value = (value << 3) + static_cast<uint64_t>(c - '0');
    }
    return value;
}

static bool streq(const char* a, const char* b) {
    uint32_t i = 0;
    while (a[i] && b[i]) {
        if (a[i] != b[i]) return false;
        ++i;
    }
    return a[i] == b[i];
}

static bool tar_name_matches(const TarHeader* h, const char* wanted) {
    char full[160];
    uint32_t n = 0;
    if (h->prefix[0]) {
        for (uint32_t i = 0; i < sizeof(h->prefix) && h->prefix[i] && n + 1 < sizeof(full); ++i) {
            full[n++] = h->prefix[i];
        }
        if (n + 1 < sizeof(full)) full[n++] = '/';
    }
    for (uint32_t i = 0; i < sizeof(h->name) && h->name[i] && n + 1 < sizeof(full); ++i) {
        full[n++] = h->name[i];
    }
    full[n] = '\0';
    return streq(full, wanted);
}

static const uint8_t* tar_find(const uint8_t* base, const char* name, uint64_t* out_size) {
    if (!base || !name || !out_size) return nullptr;

    uint64_t off = 0;
    while (off + sizeof(TarHeader) <= kInitrdScanLimit) {
        const auto* h = reinterpret_cast<const TarHeader*>(base + off);
        if (block_zero(base + off)) return nullptr;
        const uint64_t size = octal_value(h->size, sizeof(h->size));
        const uint64_t data_off = off + sizeof(TarHeader);
        const uint64_t rounded = (size + 511ull) & ~511ull;
        if (data_off + rounded < data_off || data_off + rounded > kInitrdScanLimit) return nullptr;
        if ((h->typeflag == '\0' || h->typeflag == '0') && tar_name_matches(h, name)) {
            *out_size = size;
            return base + data_off;
        }
        off = data_off + rounded;
    }
    return nullptr;
}


static bool ascii_space(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\n';
}

static bool key_at(const uint8_t* data, uint64_t size, uint64_t off, const char* key) {
    if (off != 0) {
        const char prev = static_cast<char>(data[off - 1]);
        if (prev != '\n' && prev != '\r') return false;
    }
    uint64_t i = off;
    while (i < size && (data[i] == ' ' || data[i] == '\t')) ++i;
    for (uint32_t k = 0; key[k]; ++k, ++i) {
        if (i >= size || static_cast<char>(data[i]) != key[k]) return false;
    }
    while (i < size && (data[i] == ' ' || data[i] == '\t')) ++i;
    return i < size && data[i] == '=';
}

static const uint8_t* manifest_value(const uint8_t* data, uint64_t size,
                                     const char* key, uint64_t* out_len) {
    if (!data || !key || !out_len) return nullptr;
    for (uint64_t off = 0; off < size; ++off) {
        if (!key_at(data, size, off, key)) continue;
        uint64_t i = off;
        while (i < size && data[i] != '=') ++i;
        if (i >= size) return nullptr;
        ++i;
        while (i < size && ascii_space(static_cast<char>(data[i]))) ++i;
        if (i >= size) return nullptr;
        if (data[i] == '"') {
            const uint64_t start = ++i;
            while (i < size && data[i] != '"') ++i;
            if (i >= size) return nullptr;
            *out_len = i - start;
            return data + start;
        }
        const uint64_t start = i;
        while (i < size && !ascii_space(static_cast<char>(data[i])) && data[i] != '#') ++i;
        *out_len = i - start;
        return data + start;
    }
    return nullptr;
}

static bool token_equals(const uint8_t* p, uint64_t len, const char* s) {
    uint64_t i = 0;
    while (i < len && s[i]) {
        if (static_cast<char>(p[i]) != s[i]) return false;
        ++i;
    }
    return i == len && s[i] == '\0';
}

static bool parse_u64_token(const uint8_t* p, uint64_t len, uint64_t* out) {
    if (!p || !out || len == 0) return false;
    uint64_t i = 0;
    uint32_t base = 10;
    if (len >= 2 && p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) {
        base = 16;
        i = 2;
    }
    if (i >= len) return false;
    uint64_t value = 0;
    for (; i < len; ++i) {
        const char c = static_cast<char>(p[i]);
        uint32_t digit = 0;
        if (c >= '0' && c <= '9') digit = static_cast<uint32_t>(c - '0');
        else if (base == 16 && c >= 'a' && c <= 'f') digit = static_cast<uint32_t>(c - 'a' + 10);
        else if (base == 16 && c >= 'A' && c <= 'F') digit = static_cast<uint32_t>(c - 'A' + 10);
        else return false;
        if (digit >= base) return false;
        if (value > (~0ull - digit) / base) return false;
        value = value * base + digit;
    }
    *out = value;
    return true;
}

static bool manifest_u64(const LinuxArtifacts& artifacts, const char* key, uint64_t* out) {
    uint64_t len = 0;
    const uint8_t* value = manifest_value(artifacts.manifest, artifacts.manifest_size, key, &len);
    return parse_u64_token(value, len, out);
}

static bool parse_linux_manifest(LinuxArtifacts* artifacts) {
    if (!artifacts || !artifacts->manifest || artifacts->manifest_size == 0) return false;

    uint64_t manifest_kernel_size = 0;
    uint64_t manifest_initramfs_size = 0;
    uint64_t manifest_dtb_size = 0;
    if (!manifest_u64(*artifacts, "kernel_size", &manifest_kernel_size) ||
        !manifest_u64(*artifacts, "initramfs_size", &manifest_initramfs_size) ||
        !manifest_u64(*artifacts, "dtb_size", &manifest_dtb_size) ||
        manifest_kernel_size != artifacts->image_size ||
        manifest_initramfs_size != artifacts->initramfs_size ||
        manifest_dtb_size != artifacts->dtb_size) {
        return false;
    }

    dango::VmLayout layout = dango::v3_layout();
    if (!manifest_u64(*artifacts, "memory_base", &layout.ram_base) ||
        !manifest_u64(*artifacts, "memory_size", &layout.ram_size) ||
        !manifest_u64(*artifacts, "kernel_load", &layout.kernel_load) ||
        !manifest_u64(*artifacts, "initramfs_load", &layout.initramfs_load) ||
        !manifest_u64(*artifacts, "dtb_load", &layout.dtb_base)) {
        return false;
    }

    layout.dtb_size = round_up_page(artifacts->dtb_size);
    if (layout.dtb_size < dango::kDtbSize) layout.dtb_size = dango::kDtbSize;
    layout.mmio_base = dango::kMmioBase;
    layout.mmio_size = dango::kMmioSize;
    layout.channel_base = dango::kChannelBase;
    layout.channel_size = dango::kChannelSize;

    uint64_t entry_len = 0;
    const uint8_t* entry = manifest_value(artifacts->manifest, artifacts->manifest_size,
                                          "entry", &entry_len);
    uint64_t entry_pc = 0;
    if (entry && token_equals(entry, entry_len, "kernel_load")) {
        entry_pc = layout.kernel_load;
    } else if (!entry || !parse_u64_token(entry, entry_len, &entry_pc)) {
        return false;
    }

    artifacts->layout = layout;
    artifacts->entry = entry_pc;
    return true;
}

static bool discover_linux_artifacts(const uint8_t* archive, LinuxArtifacts* out) {
    if (!archive || !out) return false;
    LinuxArtifacts artifacts{};
    artifacts.manifest = tar_find(archive, "linux/manifest.toml", &artifacts.manifest_size);
    artifacts.image = tar_find(archive, "linux/Image", &artifacts.image_size);
    artifacts.initramfs = tar_find(archive, "linux/initramfs.cpio", &artifacts.initramfs_size);
    artifacts.dtb = tar_find(archive, "linux/dango-linux.dtb", &artifacts.dtb_size);
    if (!artifacts.manifest || !artifacts.image || !artifacts.initramfs || !artifacts.dtb) {
        return false;
    }
    if (!parse_linux_manifest(&artifacts)) return false;
    out->manifest = artifacts.manifest;
    out->manifest_size = artifacts.manifest_size;
    out->image = artifacts.image;
    out->image_size = artifacts.image_size;
    out->initramfs = artifacts.initramfs;
    out->initramfs_size = artifacts.initramfs_size;
    out->dtb = artifacts.dtb;
    out->dtb_size = artifacts.dtb_size;
    out->layout.ram_base = artifacts.layout.ram_base;
    out->layout.ram_size = artifacts.layout.ram_size;
    out->layout.kernel_load = artifacts.layout.kernel_load;
    out->layout.initramfs_load = artifacts.layout.initramfs_load;
    out->layout.dtb_base = artifacts.layout.dtb_base;
    out->layout.dtb_size = artifacts.layout.dtb_size;
    out->layout.mmio_base = artifacts.layout.mmio_base;
    out->layout.mmio_size = artifacts.layout.mmio_size;
    out->layout.channel_base = artifacts.layout.channel_base;
    out->layout.channel_size = artifacts.layout.channel_size;
    out->entry = artifacts.entry;
    return true;
}

static uint64_t guest_offset(const dango::VmLayout& layout, uint64_t guest_pa) {
    return guest_pa - layout.ram_base;
}

static void runner_entry(uint64_t vcpu_arg) {
    const CapHandle vcpu = static_cast<CapHandle>(vcpu_arg);
    while (true) {
        dango::VcpuRunBudget budget{};
        budget.budget_ns = kLinuxRunBudgetNs;
        budget.deadline_ns = kLinuxRunPeriodNs;
        budget.max_exits = kLinuxRunMaxExits;

        dango::VcpuRunResult result{};
        const int64_t rc = sys_vcpu_run(vcpu, &budget, &result);
        if (rc == dango::E_NOTIMPL || result.exit_reason == dango::VCPU_EXIT_UNSUPPORTED_TRAP ||
            result.exit_reason == dango::VCPU_EXIT_SHUTDOWN) {
            break;
        }
        if (rc < 0) {
            sys_yield();
        }
    }
    sys_thread_exit(0);
}

extern "C" [[noreturn]] void _start() {
    auto* log_ring = wait_map<RingPage>(kConsoleRing, dango::CAP_SHARED_RING,
                                        kVaConsoleRing,
                                        dango::RIGHT_READ | dango::RIGHT_WRITE);
    wait_cap(kConsoleDoorbell, dango::CAP_DOORBELL);
    mochi::log_set_sink(log_ring, kRingOrder, kConsoleDoorbell, "dango.manager");
    wait_cap(kVmRoot, dango::CAP_VM_ROOT);
    wait_cap(kDoneDoorbell, dango::CAP_DOORBELL);
    wait_cap(kAuthGateDoorbell, dango::CAP_DOORBELL);
    wait_cap(kLayoutDoneDoorbell, dango::CAP_DOORBELL);
    const uint8_t* boot_archive = wait_map<uint8_t>(kBootInitrd, dango::CAP_PAGE,
                                                    kVaBootInitrd,
                                                    dango::RIGHT_READ);

    const uint64_t auth_gate_base = sys_doorbell_read(kAuthGateDoorbell);

    dango_log("manager starting\n");
    LinuxArtifacts linux{};
    const bool have_linux = discover_linux_artifacts(boot_archive, &linux);
    if (have_linux) dango_log("linux artifacts ready\n");

    const int64_t el = sys_debug_counter(dango::VM_DEBUG_EL_CURRENT);
    const int64_t el2 = sys_debug_counter(dango::VM_DEBUG_EL2_AVAILABLE);
    const int64_t vhe = sys_debug_counter(dango::VM_DEBUG_VHE_AVAILABLE);
    if (el < 0 || el > 3 || el2 < 0 || vhe < 0) fail("el2 detection failed\n");
    dango_debug("el2 available\n");

    const dango::VmLayout layout = have_linux ? linux.layout : dango::v3_layout();
    if (!validate_layout(layout)) fail("layout validation failed\n");
    const uint64_t active_ram_size = have_linux ? layout.ram_size : (16ull * 1024ull * 1024ull);

    dango_debug("creating vm\n");
    const int64_t vm_rc = sys_vm_create(kVmRoot, 0);
    if (vm_rc < 0) fail("vm create syscall failed\n");
    const CapHandle vm = as_cap(vm_rc);
    if (vm == kNullCap) fail("vm object invalid\n");
    dango_log("vm created\n");

    dango_debug("inspecting vm\n");
    dango::VmInfo vm_info{};
    if (sys_vm_inspect(vm, &vm_info, sizeof(vm_info)) != 0 ||
        vm_info.state != dango::VM_CREATED) {
        fail("vm object invalid\n");
    }
    dango_debug("vm object ready\n");

    dango_debug("creating guest memory\n");
    const CapHandle memory = as_cap(sys_vm_memory_create(vm, active_ram_size, 0));
    if (memory == kNullCap) fail("guest memory failed\n");
    dango_debug("guest memory created\n");

    const uint32_t guest_rights = dango::RIGHT_READ | dango::RIGHT_WRITE | dango::RIGHT_EXEC;
    dango_debug("mapping guest memory\n");
    if (sys_vm_memory_map(vm, memory, layout.ram_base, active_ram_size, guest_rights) != 0) {
        fail("guest memory failed\n");
    }
    dango_debug("guest memory mapped\n");

    dango_debug("inspecting guest memory\n");
    dango::VmMemoryInfo mem_info{};
    if (sys_vm_memory_inspect(memory, &mem_info, sizeof(mem_info)) != 0 ||
        mem_info.guest_pa_base != layout.ram_base ||
        mem_info.mapped_size != active_ram_size ||
        mem_info.mapped_stage2 == 0) {
        fail("guest memory failed\n");
    }
    dango_debug("guest memory ready\n");

    dango_debug("inspecting stage2\n");
    if (sys_vm_inspect(vm, &vm_info, sizeof(vm_info)) != 0 ||
        vm_info.stage2_active != 0 ||
        vm_info.stage2_built == 0 ||
        vm_info.stage2_mapped_pages != (active_ram_size / dango::kPageSize)) {
        fail("stage2 invalid\n");
    }
    dango_debug("stage2 ready\n");

    if (have_linux) {
        if (!contains(layout.ram_base, layout.ram_size, layout.kernel_load, linux.image_size) ||
            !contains(layout.ram_base, layout.ram_size, layout.initramfs_load, linux.initramfs_size) ||
            !contains(layout.ram_base, layout.ram_size, layout.dtb_base, linux.dtb_size) ||
            linux.dtb_size > layout.dtb_size ||
            !contains(layout.ram_base, layout.ram_size, linux.entry, 4) ||
            overlaps(layout.kernel_load, linux.image_size,
                     layout.initramfs_load, linux.initramfs_size) ||
            overlaps(layout.kernel_load, linux.image_size,
                     layout.dtb_base, linux.dtb_size) ||
            overlaps(layout.initramfs_load, linux.initramfs_size,
                     layout.dtb_base, linux.dtb_size)) {
            fail("linux load failed\n");
        }
        dango_debug("copying linux image\n");
        if (sys_vm_memory_write(memory,
                                guest_offset(layout, layout.kernel_load),
                                linux.image,
                                linux.image_size) != 0) {
            fail("linux load failed\n");
        }
        dango_debug("linux image copied\n");

        dango_debug("copying linux initramfs\n");
        if (sys_vm_memory_write(memory,
                                guest_offset(layout, layout.initramfs_load),
                                linux.initramfs,
                                linux.initramfs_size) != 0) {
            fail("linux load failed\n");
        }
        dango_debug("linux initramfs copied\n");

        dango_debug("copying linux dtb\n");
        if (sys_vm_memory_write(memory,
                                guest_offset(layout, layout.dtb_base),
                                linux.dtb,
                                linux.dtb_size) != 0) {
            fail("linux load failed\n");
        }
        dango_debug("linux dtb copied\n");

        dango_log("linux image loaded\n");
    }

    dango_debug("creating vcpu\n");
    const CapHandle vcpu = as_cap(sys_vcpu_create(vm, 0));
    if (vcpu == kNullCap) fail("vcpu object invalid\n");
    dango_debug("vcpu created\n");

    const uint64_t entry_pc = have_linux ? linux.entry : 0x4008'0000ull;
    dango_debug("setting vcpu entry\n");
    if (sys_vcpu_set_entry(vcpu, entry_pc, layout.dtb_base, 0) != 0) {
        fail("vcpu object invalid\n");
    }
    dango_debug("vcpu entry set\n");

    dango_debug("inspecting vcpu\n");
    dango::VcpuInfo vcpu_info{};
    if (sys_vcpu_inspect(vcpu, &vcpu_info, sizeof(vcpu_info)) != 0 ||
        (vcpu_info.state != dango::VCPU_CONFIGURED &&
         vcpu_info.state != dango::VCPU_READY) ||
        vcpu_info.entry_pc != entry_pc) {
        fail("vcpu object invalid\n");
    }
    dango_debug("vcpu ready\n");

    dango::SchedContext vcpu_sched{};
    vcpu_sched.band = dango::SCHED_BAND_VM_LATENCY;
    vcpu_sched.weight = 1024;
    vcpu_sched.budget_ns = kLinuxRunBudgetNs;
    vcpu_sched.period_ns = kLinuxRunPeriodNs;
    vcpu_sched.deadline_ns = kLinuxRunPeriodNs;
    vcpu_sched.core_mask = 1ull << 1;
    vcpu_sched.home_cpu = 1;
    vcpu_sched.flags = dango::SCHED_CTX_VM_RUNNER | dango::SCHED_CTX_NO_STEAL;
    const CapHandle vcpu_sched_ctx = as_cap(sys_sched_context_create(&vcpu_sched, sizeof(vcpu_sched)));
    if (vcpu_sched_ctx == kNullCap || sys_vcpu_bind_sched_context(vcpu, vcpu_sched_ctx) != 0 ||
        sys_vcpu_set_core_mask(vcpu, vcpu_sched.core_mask, vcpu_sched.home_cpu) != 0) {
        fail("vcpu scheduler setup failed\n");
    }

    if (!have_linux) {
        dango::VcpuRunBudget probe_budget{};
        probe_budget.budget_ns = kLinuxRunBudgetNs;
        probe_budget.deadline_ns = kLinuxRunPeriodNs;
        probe_budget.max_exits = 100;
        dango::VcpuRunResult probe_result{};
        if (sys_vcpu_run(vcpu, &probe_budget, &probe_result) != dango::E_NOTIMPL) {
            fail("vcpu stub run failed\n");
        }
        console_log("vcpu stub run complete\n");
    }

    const CapHandle channel = as_cap(sys_vm_channel_create(vm, kRingOrder, 0));
    if (channel == kNullCap) fail("channel setup failed\n");
    const CapHandle h2g_ring = as_cap(sys_vm_channel_endpoint(
        channel, dango::VM_CHANNEL_HOST_TO_GUEST_RING,
        dango::RIGHT_READ | dango::RIGHT_WRITE | dango::RIGHT_MAP | dango::RIGHT_DUP));
    const CapHandle g2h_ring = as_cap(sys_vm_channel_endpoint(
        channel, dango::VM_CHANNEL_GUEST_TO_HOST_RING,
        dango::RIGHT_READ | dango::RIGHT_WRITE | dango::RIGHT_MAP | dango::RIGHT_DUP));
    const CapHandle h2g_db = as_cap(sys_vm_channel_endpoint(
        channel, dango::VM_CHANNEL_HOST_TO_GUEST_DOORBELL,
        dango::RIGHT_NOTIFY | dango::RIGHT_WAIT | dango::RIGHT_DUP));
    const CapHandle g2h_db = as_cap(sys_vm_channel_endpoint(
        channel, dango::VM_CHANNEL_GUEST_TO_HOST_DOORBELL,
        dango::RIGHT_NOTIFY | dango::RIGHT_WAIT | dango::RIGHT_DUP));
    if (h2g_ring == kNullCap || g2h_ring == kNullCap ||
        h2g_db == kNullCap || g2h_db == kNullCap ||
        sys_cap_identify(h2g_ring) != dango::CAP_SHARED_RING ||
        sys_cap_identify(g2h_ring) != dango::CAP_SHARED_RING ||
        sys_cap_identify(h2g_db) != dango::CAP_DOORBELL ||
        sys_cap_identify(g2h_db) != dango::CAP_DOORBELL) {
        fail("channel setup failed\n");
    }
    dango::VmChannelInfo channel_info{};
    if (sys_vm_channel_inspect(channel, &channel_info, sizeof(channel_info)) != 0 ||
        channel_info.endpoint_present_mask != 0xFull) {
        fail("channel setup failed\n");
    }
    console_log("channel ready\n");
    console_log("layout ready\n");

    if (sys_notify(kLayoutDoneDoorbell) != 0) fail("service failed\n");
    if (sys_wait_doorbell(kAuthGateDoorbell, auth_gate_base) != 0) {
        fail("service failed\n");
    }

    if (have_linux) {
        dango_log("starting linux guest\n");
        const CapHandle runner_th = as_cap(
            sys_thread_create(kNullCap,
                              reinterpret_cast<uint64_t>(runner_entry),
                              static_cast<uint64_t>(vcpu),
                              THREAD_SUSPENDED));
        if (runner_th != kNullCap) {
            sys_thread_set_affinity(runner_th, 1ull << 1);
            if (sys_sched_context_bind_thread(runner_th, vcpu_sched_ctx) != 0) {
                fail("vcpu scheduler setup failed\n");
            }
            sys_thread_resume(runner_th);
            dango_log("vm runner started async\n");
        } else {
            dango_debug("vm runner create failed\n");
        }
    }

    console_log("service ready\n");
    (void)sys_notify(kDoneDoorbell);

    bool logged_agent = false;
    bool logged_hello = false;
    while (true) {
        if (have_linux && !logged_hello) {
            const int64_t saw_hello = sys_debug_counter(dango::VM_DEBUG_GUEST_LINUX_HELLO);
            const int64_t saw_agent = sys_debug_counter(dango::VM_DEBUG_GUEST_AGENT_START);
            if (saw_hello > 0) {
                dango_log("linux guest responded\n");
                logged_hello = true;
            } else if (!logged_agent && saw_agent > 0) {
                dango_log("linux guest agent started\n");
                logged_agent = true;
            }
        }
        sys_yield();
    }
}
