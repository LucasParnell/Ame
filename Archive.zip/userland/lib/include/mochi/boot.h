#pragma once
// Process BootInfo helpers.
//
// BootInfo is the programmer-facing replacement for fixed cap-slot folklore.
// The only fixed slot is slot 0: a one-page MxBootInfo arena granted by init.
// Every other service capability is found by name and type from that page.

#include "midix/abi/boot.h"
#include "midix/abi/cap.h"
#include "mochi/syscall.h"

namespace mochi::boot {

constexpr mx_vaddr_t kDefaultBootInfoVa = 0x1000'0000ull;

constexpr CapHandle cap_slot(uint32_t idx) {
    return (static_cast<CapHandle>(1) << 32) | idx;
}

constexpr CapHandle kBootInfoCap = cap_slot(0);

static inline uint32_t slen(const char* s) {
    uint32_t n = 0;
    if (!s) return 0;
    while (s[n]) ++n;
    return n;
}

static inline bool streq(const char* a, const char* b) {
    if (!a || !b) return false;
    uint32_t i = 0;
    while (a[i] && b[i]) {
        if (a[i] != b[i]) return false;
        ++i;
    }
    return a[i] == b[i];
}

static inline MxBootInfo* map(mx_vaddr_t va = kDefaultBootInfoVa) {
    // The BootInfo page is always a normal arena cap so services can treat it
    // like any other mapped userland object. The loop permits init to grant the
    // cap before filling the magic word, without racing service startup.
    while (true) {
        mx_i64_t type = 0;
        if (mx_cap_identify(kBootInfoCap, &type) == MX_OK && type == MX_CAP_ARENA) {
            if (mx_map_page(kBootInfoCap, va, MX_RIGHT_READ | MX_RIGHT_WRITE) == MX_OK) {
                auto* info = reinterpret_cast<MxBootInfo*>(va);
                while (__atomic_load_n(&info->magic, __ATOMIC_ACQUIRE) != MX_BOOT_MAGIC) {
                    mx_yield();
                }
                return info;
            }
        }
        mx_yield();
    }
}

static inline bool valid(const MxBootInfo* info) {
    return info && info->magic == MX_BOOT_MAGIC && info->version == MX_BOOT_VERSION &&
           info->entry_count <= MX_BOOT_MAX_ENTRIES;
}

static inline const MxBootEntry* find(const MxBootInfo* info, const char* name) {
    if (!valid(info) || !name) return nullptr;
    for (uint16_t i = 0; i < info->entry_count; ++i) {
        if (streq(info->entries[i].name, name)) return &info->entries[i];
    }
    return nullptr;
}

static inline const MxBootEntry* find_type(const MxBootInfo* info, const char* name,
                                           MxBootEntryType type) {
    const MxBootEntry* entry = find(info, name);
    if (!entry || entry->type != static_cast<mx_u32_t>(type)) return nullptr;
    return entry;
}

static inline mx_handle_t handle(const MxBootInfo* info, const char* name) {
    const MxBootEntry* entry = find(info, name);
    return entry ? entry->handle : MX_NULL_HANDLE;
}

static inline mx_handle_t require_handle(const MxBootInfo* info, const char* name) {
    mx_handle_t h = handle(info, name);
    while (h == MX_NULL_HANDLE) {
        mx_yield();
        h = handle(info, name);
    }
    return h;
}

} // namespace mochi::boot
