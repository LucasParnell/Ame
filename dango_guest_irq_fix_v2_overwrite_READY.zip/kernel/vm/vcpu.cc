#include "anko/vm.h"
#include "anko/platform.h"
#include "anko/log.h"
#include "libk/printf.h"
#include "libk/string.h"

extern "C" u64 g_boot_el;
extern "C" u64 vm_el2_run(vm::El2RunState* state);

namespace vm {

namespace {

u32 g_next_vcpu_id = 1;

constexpr u64 kLinuxBootProbeEntry = 0x4008'0000ull;
constexpr u64 kHcrExitUnsupported = 0;
constexpr u64 kEcWfx = 0x01;
constexpr u64 kEcSysReg = 0x18;
constexpr u64 kEcInstrAbortLower = 0x20;
constexpr u64 kEcInstrAbortCurrent = 0x21;
constexpr u64 kEcDataAbortLower = 0x24;
constexpr u64 kEcDataAbortCurrent = 0x25;
constexpr u64 kQemuUartBase = 0x0900'0000ull;
constexpr u64 kQemuGicDistBase = 0x0800'0000ull;
constexpr u64 kQemuGicCpuBase = 0x0801'0000ull;
constexpr u64 kMmioPageSize = 0x1000;

constexpr u32 kGicSpuriousIrq = 1023;
constexpr u32 kGuestPhysTimerIrq = 30;
constexpr u32 kGuestVirtTimerIrq = 27;

constexpr u32 GICD_CTLR       = 0x000;
constexpr u32 GICD_TYPER      = 0x004;
constexpr u32 GICD_IIDR       = 0x008;
constexpr u32 GICD_IGROUPR    = 0x080;
constexpr u32 GICD_ISENABLER  = 0x100;
constexpr u32 GICD_ICENABLER  = 0x180;
constexpr u32 GICD_ISPENDR    = 0x200;
constexpr u32 GICD_ICPENDR    = 0x280;
constexpr u32 GICD_ISACTIVER  = 0x300;
constexpr u32 GICD_ICACTIVER  = 0x380;
constexpr u32 GICD_IPRIORITYR = 0x400;
constexpr u32 GICD_ITARGETSR  = 0x800;
constexpr u32 GICD_ICFGR      = 0xC00;
constexpr u32 GICD_SGIR       = 0xF00;

constexpr u32 GICC_CTLR  = 0x000;
constexpr u32 GICC_PMR   = 0x004;
constexpr u32 GICC_BPR   = 0x008;
constexpr u32 GICC_IAR   = 0x00C;
constexpr u32 GICC_EOIR  = 0x010;
constexpr u32 GICC_RPR   = 0x014;
constexpr u32 GICC_HPPIR = 0x018;
constexpr u32 GICC_IIDR  = 0x0FC;
constexpr u32 GICC_DIR   = 0x1000;

u64 esr_ec(u64 esr) {
    return (esr >> 26) & 0x3Full;
}

u64 esr_iss(u64 esr) {
    return esr & 0x01FF'FFFFull;
}

u64 read_cntpct() {
    u64 value = 0;
    asm volatile("mrs %0, CNTPCT_EL0" : "=r"(value));
    return value;
}

bool timer_enabled_unmasked(u64 ctl) {
    return (ctl & 0x1ull) && ((ctl & 0x2ull) == 0);
}

u64 data_abort_ipa(const El2RunState& state) {
    return ((state.exit_hpfar & 0xFFFF'FFFF'FFFF'F0ull) << 8) |
           (state.exit_far & 0xFFFull);
}

u64 fault_ipa(const El2RunState& state, u64 ec) {
    if (ec == kEcDataAbortLower || ec == kEcDataAbortCurrent ||
        ec == kEcInstrAbortLower || ec == kEcInstrAbortCurrent) {
        return ((state.exit_hpfar & 0xFFFF'FFFF'FFFF'F0ull) << 8) |
               (state.exit_far & 0xFFFull);
    }
    return 0;
}

u32 data_abort_size(u64 esr) {
    const u64 iss = esr & 0x01FF'FFFFull;
    if (((iss >> 24) & 1ull) == 0) return 0;
    const u32 sas = static_cast<u32>((iss >> 22) & 0x3ull);
    return 1u << sas;
}

u32 data_abort_reg(u64 esr) {
    return static_cast<u32>((esr >> 16) & 0x1Full);
}

bool data_abort_write(u64 esr) {
    return ((esr >> 6) & 1ull) != 0;
}

u64 read_reg(const El2RunState& state, u32 reg) {
    if (reg >= 31) return 0;
    return state.regs[reg];
}

void write_reg(El2RunState& state, u32 reg, u64 value, u32 size) {
    if (reg >= 31) return;
    if (size <= 4) value &= 0xFFFF'FFFFull;
    state.regs[reg] = value;
}

u64 mask_width(u32 size) {
    if (size >= 8) return ~0ull;
    return (1ull << (size * 8)) - 1ull;
}

u64 pl011_read(u64 offset) {
    switch (offset) {
    case 0x000: return 0;
    case 0x018: return (1u << 7) | (1u << 4);
    case 0x024: return 0;
    case 0x028: return 0;
    case 0x02C: return 0;
    case 0x030: return 0;
    case 0x038: return 0;
    case 0xFE0: return 0x11;
    case 0xFE4: return 0x10;
    case 0xFE8: return 0x14;
    case 0xFEC: return 0x00;
    case 0xFF0: return 0x0D;
    case 0xFF4: return 0xF0;
    case 0xFF8: return 0x05;
    case 0xFFC: return 0xB1;
    default: return 0;
    }
}

void note_guest_console_char(char c) {
    static char line[96];
    static u32 len = 0;
    static bool saw_boot_stub = false;
    static bool saw_agent_start = false;
    static bool saw_linux_hello = false;

    if (c == '\r') return;

    if (c == '\n') {
        line[len] = '\0';
        if (!saw_boot_stub && libk::strcmp(line, "DANGO VM BOOT STUB OK") == 0) {
            saw_boot_stub = true;
            metric_inc(VM_DEBUG_GUEST_BOOT_STUB);
            ANKO_LOG_RAW("DANGO GUEST BOOT STUB OK\n");
        }
        if (!saw_agent_start && libk::strcmp(line, "DANGO AGENT START") == 0) {
            saw_agent_start = true;
            metric_inc(VM_DEBUG_GUEST_AGENT_START);
            ANKO_LOG_RAW("DANGO GUEST AGENT START OK\n");
        }
        if (!saw_linux_hello && libk::strcmp(line, "DANGO LINUX HELLO OK") == 0) {
            saw_linux_hello = true;
            metric_inc(VM_DEBUG_GUEST_LINUX_HELLO);
            ANKO_LOG_RAW("DANGO GUEST UART HELLO OK\n");
        }
        len = 0;
        return;
    }

    if (len + 1 < sizeof(line)) {
        line[len++] = c;
    } else {
        len = 0;
    }
}

void guest_console_putchar(char c) {
    auto* base = reinterpret_cast<volatile u32*>(platform::kGuestUartBase);
    base[platform::kUartDR / 4] = static_cast<u32>(static_cast<unsigned char>(c));
}

void pl011_write(u64 offset, u64 value) {
    if (offset == 0x000) {
        const char c = static_cast<char>(value & 0xFFu);
        guest_console_putchar(c);
        note_guest_console_char(c);
    }
}

u32 lane_shift(u64 offset) {
    return static_cast<u32>((offset & 0x3ull) * 8ull);
}

u32 sized_write_bits(u64 offset, u32 size, u64 value) {
    const u32 shift = lane_shift(offset);
    if (size >= 4) return static_cast<u32>(value);
    const u32 bits = static_cast<u32>(value) & ((1u << (size * 8u)) - 1u);
    return bits << shift;
}

u32 merge_sized_write(u32 old_value, u64 offset, u32 size, u64 value) {
    const u32 shift = lane_shift(offset);
    if (size >= 4) return static_cast<u32>(value);
    const u32 mask = ((1u << (size * 8u)) - 1u) << shift;
    const u32 bits = (static_cast<u32>(value) << shift) & mask;
    return (old_value & ~mask) | bits;
}

u64 extract_sized_read(u32 value, u64 offset, u32 size) {
    const u32 shift = lane_shift(offset);
    if (size >= 4) return value;
    const u32 mask = (1u << (size * 8u)) - 1u;
    return (value >> shift) & mask;
}

u32 bitmap_word_index(u32 irq) { return irq / 32u; }
u32 bitmap_mask(u32 irq) { return 1u << (irq % 32u); }
bool irq_in_range(u32 irq) { return irq < kVgicMaxIrqs; }

bool vgic_bit_test(const u32* bitmap, u32 irq) {
    return irq_in_range(irq) && ((bitmap[bitmap_word_index(irq)] & bitmap_mask(irq)) != 0);
}

void vgic_bit_set(u32* bitmap, u32 irq) {
    if (irq_in_range(irq)) bitmap[bitmap_word_index(irq)] |= bitmap_mask(irq);
}

void vgic_bit_clear(u32* bitmap, u32 irq) {
    if (irq_in_range(irq)) bitmap[bitmap_word_index(irq)] &= ~bitmap_mask(irq);
}

u32 vgic_bitmap_word(const u32* bitmap, u32 word) {
    return (word < kVgicBitmapWords) ? bitmap[word] : 0;
}

void vgic_init(VgicState& gic) {
    libk::memset(&gic, 0, sizeof(gic));
    gic.cpu_pmr = 0xFF;
    gic.last_iar = kGicSpuriousIrq;
    for (u32 i = 0; i < kVgicMaxIrqs; ++i) {
        gic.priority[i] = 0xA0;
        gic.targets[i] = 0x01;
    }
}

bool vgic_irq_enabled(const VgicState& gic, u32 irq) {
    return irq_in_range(irq) &&
           ((gic.dist_ctlr & 1u) != 0) &&
           ((gic.cpu_ctlr & 1u) != 0) &&
           vgic_bit_test(gic.enabled, irq) &&
           vgic_bit_test(gic.pending, irq) &&
           !vgic_bit_test(gic.active, irq) &&
           gic.priority[irq] <= gic.cpu_pmr;
}

u32 vgic_peek_irq(const VgicState& gic) {
    u32 best_irq = kGicSpuriousIrq;
    u8 best_priority = 0xFF;
    for (u32 irq = 0; irq < kVgicMaxIrqs; ++irq) {
        if (!vgic_irq_enabled(gic, irq)) continue;
        const u8 priority = gic.priority[irq];
        if (best_irq == kGicSpuriousIrq || priority < best_priority) {
            best_irq = irq;
            best_priority = priority;
        }
    }
    return best_irq;
}

void vgic_set_level(Vcpu& vcpu, u32 irq, bool asserted) {
    if (!irq_in_range(irq)) return;
    if (asserted) {
        vgic_bit_set(vcpu.vgic.level, irq);
        if (!vgic_bit_test(vcpu.vgic.active, irq)) vgic_bit_set(vcpu.vgic.pending, irq);
    } else {
        vgic_bit_clear(vcpu.vgic.level, irq);
        if (!vgic_bit_test(vcpu.vgic.active, irq)) vgic_bit_clear(vcpu.vgic.pending, irq);
    }
}

u32 vgic_ack_irq(Vcpu& vcpu) {
    const u32 irq = vgic_peek_irq(vcpu.vgic);
    if (irq == kGicSpuriousIrq) {
        vcpu.vgic.last_iar = kGicSpuriousIrq;
        return kGicSpuriousIrq;
    }
    vgic_bit_clear(vcpu.vgic.pending, irq);
    vgic_bit_set(vcpu.vgic.active, irq);
    vcpu.vgic.last_iar = irq;
    return irq;
}

void vgic_deactivate_irq(Vcpu& vcpu, u32 irq) {
    if (!irq_in_range(irq)) return;
    vgic_bit_clear(vcpu.vgic.active, irq);
    if (vgic_bit_test(vcpu.vgic.level, irq)) vgic_bit_set(vcpu.vgic.pending, irq);
}

u32 priority_word(const VgicState& gic, u32 index) {
    const u32 base = index * 4u;
    u32 value = 0;
    for (u32 i = 0; i < 4; ++i) {
        const u32 irq = base + i;
        value |= static_cast<u32>(irq_in_range(irq) ? gic.priority[irq] : 0) << (i * 8u);
    }
    return value;
}

void priority_word_write(VgicState& gic, u32 index, u64 offset, u32 size, u64 value) {
    const u32 merged = merge_sized_write(priority_word(gic, index), offset, size, value);
    const u32 base = index * 4u;
    for (u32 i = 0; i < 4; ++i) {
        const u32 irq = base + i;
        if (irq_in_range(irq)) gic.priority[irq] = static_cast<u8>((merged >> (i * 8u)) & 0xFFu);
    }
}

u32 target_word(const VgicState& gic, u32 index) {
    const u32 base = index * 4u;
    u32 value = 0;
    for (u32 i = 0; i < 4; ++i) {
        const u32 irq = base + i;
        value |= static_cast<u32>(irq_in_range(irq) ? gic.targets[irq] : 0) << (i * 8u);
    }
    return value;
}

void target_word_write(VgicState& gic, u32 index, u64 offset, u32 size, u64 value) {
    const u32 merged = merge_sized_write(target_word(gic, index), offset, size, value);
    const u32 base = index * 4u;
    for (u32 i = 0; i < 4; ++i) {
        const u32 irq = base + i;
        if (irq_in_range(irq)) gic.targets[irq] = static_cast<u8>((merged >> (i * 8u)) & 0xFFu);
    }
}

u64 gic_dist_read(const Vcpu& vcpu, u64 offset, u32 size) {
    const VgicState& gic = vcpu.vgic;
    u32 word = 0;
    if (offset >= GICD_CTLR && offset < GICD_CTLR + 4) {
        word = gic.dist_ctlr & 1u;
    } else if (offset >= GICD_TYPER && offset < GICD_TYPER + 4) {
        word = 1u; // 64 interrupts, one CPU
    } else if (offset >= GICD_IIDR && offset < GICD_IIDR + 4) {
        word = 0x0200'143Bull;
    } else if (offset >= GICD_IGROUPR && offset < GICD_IGROUPR + 0x80) {
        word = vgic_bitmap_word(gic.group, static_cast<u32>((offset - GICD_IGROUPR) / 4));
    } else if (offset >= GICD_ISENABLER && offset < GICD_ISENABLER + 0x80) {
        word = vgic_bitmap_word(gic.enabled, static_cast<u32>((offset - GICD_ISENABLER) / 4));
    } else if (offset >= GICD_ICENABLER && offset < GICD_ICENABLER + 0x80) {
        word = vgic_bitmap_word(gic.enabled, static_cast<u32>((offset - GICD_ICENABLER) / 4));
    } else if (offset >= GICD_ISPENDR && offset < GICD_ISPENDR + 0x80) {
        word = vgic_bitmap_word(gic.pending, static_cast<u32>((offset - GICD_ISPENDR) / 4));
    } else if (offset >= GICD_ICPENDR && offset < GICD_ICPENDR + 0x80) {
        word = vgic_bitmap_word(gic.pending, static_cast<u32>((offset - GICD_ICPENDR) / 4));
    } else if (offset >= GICD_ISACTIVER && offset < GICD_ISACTIVER + 0x80) {
        word = vgic_bitmap_word(gic.active, static_cast<u32>((offset - GICD_ISACTIVER) / 4));
    } else if (offset >= GICD_ICACTIVER && offset < GICD_ICACTIVER + 0x80) {
        word = vgic_bitmap_word(gic.active, static_cast<u32>((offset - GICD_ICACTIVER) / 4));
    } else if (offset >= GICD_IPRIORITYR && offset < GICD_IPRIORITYR + 0x400) {
        word = priority_word(gic, static_cast<u32>((offset - GICD_IPRIORITYR) / 4));
    } else if (offset >= GICD_ITARGETSR && offset < GICD_ITARGETSR + 0x400) {
        word = target_word(gic, static_cast<u32>((offset - GICD_ITARGETSR) / 4));
    } else if (offset >= GICD_ICFGR && offset < GICD_ICFGR + 0x100) {
        const u32 index = static_cast<u32>((offset - GICD_ICFGR) / 4);
        word = (index < (kVgicMaxIrqs / 16)) ? gic.config[index] : 0;
    }
    return extract_sized_read(word, offset, size);
}

void gic_dist_write(Vcpu& vcpu, u64 offset, u32 size, u64 value) {
    VgicState& gic = vcpu.vgic;
    const u32 bits = sized_write_bits(offset, size, value);
    if (offset >= GICD_CTLR && offset < GICD_CTLR + 4) {
        gic.dist_ctlr = merge_sized_write(gic.dist_ctlr, offset, size, value) & 1u;
    } else if (offset >= GICD_IGROUPR && offset < GICD_IGROUPR + 0x80) {
        const u32 word = static_cast<u32>((offset - GICD_IGROUPR) / 4);
        if (word < kVgicBitmapWords) gic.group[word] = merge_sized_write(gic.group[word], offset, size, value);
    } else if (offset >= GICD_ISENABLER && offset < GICD_ISENABLER + 0x80) {
        const u32 word = static_cast<u32>((offset - GICD_ISENABLER) / 4);
        if (word < kVgicBitmapWords) gic.enabled[word] |= bits;
    } else if (offset >= GICD_ICENABLER && offset < GICD_ICENABLER + 0x80) {
        const u32 word = static_cast<u32>((offset - GICD_ICENABLER) / 4);
        if (word < kVgicBitmapWords) gic.enabled[word] &= ~bits;
    } else if (offset >= GICD_ISPENDR && offset < GICD_ISPENDR + 0x80) {
        const u32 word = static_cast<u32>((offset - GICD_ISPENDR) / 4);
        if (word < kVgicBitmapWords) gic.pending[word] |= bits;
    } else if (offset >= GICD_ICPENDR && offset < GICD_ICPENDR + 0x80) {
        const u32 word = static_cast<u32>((offset - GICD_ICPENDR) / 4);
        if (word < kVgicBitmapWords) gic.pending[word] &= ~bits;
    } else if (offset >= GICD_ISACTIVER && offset < GICD_ISACTIVER + 0x80) {
        const u32 word = static_cast<u32>((offset - GICD_ISACTIVER) / 4);
        if (word < kVgicBitmapWords) gic.active[word] |= bits;
    } else if (offset >= GICD_ICACTIVER && offset < GICD_ICACTIVER + 0x80) {
        const u32 word = static_cast<u32>((offset - GICD_ICACTIVER) / 4);
        if (word < kVgicBitmapWords) gic.active[word] &= ~bits;
    } else if (offset >= GICD_IPRIORITYR && offset < GICD_IPRIORITYR + 0x400) {
        priority_word_write(gic, static_cast<u32>((offset - GICD_IPRIORITYR) / 4), offset, size, value);
    } else if (offset >= GICD_ITARGETSR && offset < GICD_ITARGETSR + 0x400) {
        target_word_write(gic, static_cast<u32>((offset - GICD_ITARGETSR) / 4), offset, size, value);
    } else if (offset >= GICD_ICFGR && offset < GICD_ICFGR + 0x100) {
        const u32 index = static_cast<u32>((offset - GICD_ICFGR) / 4);
        if (index < (kVgicMaxIrqs / 16)) gic.config[index] = merge_sized_write(gic.config[index], offset, size, value);
    } else if (offset >= GICD_SGIR && offset < GICD_SGIR + 4) {
        const u32 sgi = static_cast<u32>(value) & 0xFu;
        const u32 target_list = (static_cast<u32>(value) >> 16) & 0xFFu;
        const u32 target_filter = (static_cast<u32>(value) >> 24) & 0x3u;
        if (sgi < 16 && (target_filter == 1 || (target_list & 0x01u))) vgic_bit_set(gic.pending, sgi);
    }
}

u64 gic_cpu_read(Vcpu& vcpu, u64 offset, u32 size) {
    VgicState& gic = vcpu.vgic;
    u32 word = 0;
    switch (offset & ~0x3ull) {
    case GICC_CTLR:  word = gic.cpu_ctlr & 1u; break;
    case GICC_PMR:   word = gic.cpu_pmr; break;
    case GICC_BPR:   word = gic.cpu_bpr; break;
    case GICC_IAR:   word = vgic_ack_irq(vcpu); break;
    case GICC_RPR:   word = 0xFF; break;
    case GICC_HPPIR: word = vgic_peek_irq(gic); break;
    case GICC_IIDR:  word = 0x0200'143Bull; break;
    default:         word = 0; break;
    }
    return extract_sized_read(word, offset, size);
}

void gic_cpu_write(Vcpu& vcpu, u64 offset, u32 size, u64 value) {
    VgicState& gic = vcpu.vgic;
    switch (offset & ~0x3ull) {
    case GICC_CTLR: gic.cpu_ctlr = merge_sized_write(gic.cpu_ctlr, offset, size, value) & 1u; break;
    case GICC_PMR:  gic.cpu_pmr = merge_sized_write(gic.cpu_pmr, offset, size, value) & 0xFFu; break;
    case GICC_BPR:  gic.cpu_bpr = merge_sized_write(gic.cpu_bpr, offset, size, value) & 0x7u; break;
    case GICC_EOIR:
    case GICC_DIR:  vgic_deactivate_irq(vcpu, static_cast<u32>(value) & 0x3FFu); break;
    default: break;
    }
}

bool emulate_mmio(Vcpu& vcpu, u64 ipa, u64 esr) {
    const u32 size = data_abort_size(esr);
    const u32 reg = data_abort_reg(esr);
    const bool write = data_abort_write(esr);
    u64 value = 0;
    bool handled = false;
    if (size == 0) {
        if (write) { vcpu.el2.pc += 4; return true; }
        return false;
    }
    if (size > 8) return false;
    if (ipa >= kQemuUartBase && ipa < kQemuUartBase + kMmioPageSize) {
        const u64 offset = ipa - kQemuUartBase;
        if (write) pl011_write(offset, read_reg(vcpu.el2, reg) & mask_width(size));
        else value = pl011_read(offset);
        handled = true;
    } else if (ipa >= kQemuGicDistBase && ipa < kQemuGicDistBase + 0x10000) {
        const u64 offset = ipa - kQemuGicDistBase;
        if (!write) value = gic_dist_read(vcpu, offset, size);
        else gic_dist_write(vcpu, offset, size, read_reg(vcpu.el2, reg) & mask_width(size));
        handled = true;
    } else if (ipa >= kQemuGicCpuBase && ipa < kQemuGicCpuBase + 0x10000) {
        const u64 offset = ipa - kQemuGicCpuBase;
        if (!write) value = gic_cpu_read(vcpu, offset, size);
        else gic_cpu_write(vcpu, offset, size, read_reg(vcpu.el2, reg) & mask_width(size));
        handled = true;
    }
    if (!handled) return false;
    if (!write) write_reg(vcpu.el2, reg, value, size);
    vcpu.el2.pc += 4;
    return true;
}

void log_sysreg_trap(const Vcpu& vcpu, u64 esr) {
    const u64 iss = esr_iss(esr);
    const u32 op0 = static_cast<u32>((iss >> 20) & 0x3ull);
    const u32 op2 = static_cast<u32>((iss >> 17) & 0x7ull);
    const u32 op1 = static_cast<u32>((iss >> 14) & 0x7ull);
    const u32 crn = static_cast<u32>((iss >> 10) & 0xFull);
    const u32 rt  = static_cast<u32>((iss >> 5)  & 0x1Full);
    const u32 crm = static_cast<u32>((iss >> 1)  & 0xFull);
    const bool read = (iss & 1ull) != 0;
    libk::printf("DANGO SYSREG TRAP %s op0=%u op1=%u crn=%u crm=%u op2=%u rt=%u pc=%llx esr=%llx\n",
                 read ? "read" : "write", op0, op1, crn, crm, op2, rt,
                 static_cast<unsigned long long>(vcpu.el2.pc), static_cast<unsigned long long>(esr));
}

void log_unsupported_exit(const Vcpu& vcpu, const Vm& owner, u64 esr, u64 ec) {
    const u64 ipa = fault_ipa(vcpu.el2, ec);
    u32 mapped_rights = 0;
    const PhysAddr mapped_pa = stage2_lookup_page(const_cast<Stage2AddressSpace*>(&owner.stage2), ipa, &mapped_rights);
    libk::printf("DANGO VM EXIT unsupported ec=%llx iss=%llx esr=%llx pc=%llx far=%llx hpfar=%llx ipa=%llx s2pa=%llx rights=%x\n",
                 static_cast<unsigned long long>(ec), static_cast<unsigned long long>(esr_iss(esr)),
                 static_cast<unsigned long long>(esr), static_cast<unsigned long long>(vcpu.el2.pc),
                 static_cast<unsigned long long>(vcpu.el2.exit_far), static_cast<unsigned long long>(vcpu.el2.exit_hpfar),
                 static_cast<unsigned long long>(ipa), static_cast<unsigned long long>(mapped_pa), mapped_rights);
}

void update_timer_lines(Vcpu& vcpu) {
    const u64 now = read_cntpct();
    const bool phys_asserted = timer_enabled_unmasked(vcpu.el2.guest_cntp_ctl) && now >= vcpu.el2.guest_cntp_cval;
    const bool virt_asserted = timer_enabled_unmasked(vcpu.el2.guest_cntv_ctl) && now >= vcpu.el2.guest_cntv_cval;
    vgic_set_level(vcpu, kGuestPhysTimerIrq, phys_asserted);
    vgic_set_level(vcpu, kGuestVirtTimerIrq, virt_asserted);
}

void prepare_guest_entry(Vcpu& vcpu) {
    update_timer_lines(vcpu);
    vcpu.el2.guest_irq_pending = (vgic_peek_irq(vcpu.vgic) != kGicSpuriousIrq) ? 1ull : 0ull;
    u64 timer_mask = 0;
    if (vgic_bit_test(vcpu.vgic.pending, kGuestPhysTimerIrq) || vgic_bit_test(vcpu.vgic.active, kGuestPhysTimerIrq)) timer_mask |= 1ull;
    if (vgic_bit_test(vcpu.vgic.pending, kGuestVirtTimerIrq) || vgic_bit_test(vcpu.vgic.active, kGuestVirtTimerIrq)) timer_mask |= 2ull;
    vcpu.el2.timer_hw_mask = timer_mask;
}

void sync_vcpu_from_el2(Vcpu& vcpu) {
    for (u32 i = 0; i < 31; ++i) vcpu.regs[i] = vcpu.el2.regs[i];
    vcpu.sp = vcpu.el2.guest_sp_el1;
    vcpu.pc = vcpu.el2.pc;
    vcpu.pstate = vcpu.el2.pstate;
}

void init_el2_state(Vcpu& vcpu, const Vm& owner) {
    if (vcpu.el2.initialized) return;
    libk::memset(&vcpu.el2, 0, sizeof(vcpu.el2));
    vcpu.el2.regs[0] = vcpu.arg0;
    vcpu.el2.regs[1] = vcpu.arg1;
    vcpu.el2.regs[2] = 0;
    vcpu.el2.regs[3] = 0;
    vcpu.el2.pc = vcpu.entry_pc;
    vcpu.el2.pstate = 0x3C5;
    vcpu.el2.guest_sctlr = 0x30D0'0800ull;
    vcpu.el2.guest_sp_el1 = 0;
    vcpu.el2.vttbr = owner.stage2.root_table_phys |
                     ((static_cast<u64>(owner.vm_id & 0xFFu)) << 48);
    vcpu.el2.vtcr =
        25ull |          // T0SZ: 39-bit IPA
        (1ull << 6) |    // SL0: level-1 root for 4 KiB granule
        (1ull << 8) |    // IRGN0: WBWA
        (1ull << 10) |   // ORGN0: WBWA
        (3ull << 12) |   // SH0: inner-shareable
        (2ull << 16);    // PS: 40-bit PA
    vcpu.el2.guest_cntp_ctl  = 0;
    vcpu.el2.guest_cntp_cval = ~0ull;
    vcpu.el2.guest_cntv_ctl  = 0;
    vcpu.el2.guest_cntv_cval = ~0ull;
    vcpu.el2.guest_irq_pending = 0;
    vcpu.el2.timer_hw_mask = 0;
    vcpu.el2.host_cntp_ctl   = 0;
    vcpu.el2.host_cntp_cval  = 0;
    vcpu.el2.initialized = 1;
}

} // namespace

CapHandle create_vcpu(Process& caller, CapHandle vm_cap, u64 flags, SysError* out_error) {
    SysError rc = E_OK;
    Vm* v = vm_from_cap(caller, vm_cap, RIGHT_VM_CONTROL, &rc);
    if (!v) {
        if (out_error) *out_error = rc;
        return kNullCap;
    }
    if (v->vcpu_count >= kMaxVcpusPerVm) {
        if (out_error) *out_error = E_OVERFLOW;
        note_error();
        return kNullCap;
    }

    Vcpu* vcpu = static_cast<Vcpu*>(mm::heap_alloc(sizeof(Vcpu), alignof(Vcpu)));
    if (!vcpu) {
        if (out_error) *out_error = E_NOMEM;
        note_error();
        return kNullCap;
    }
    libk::memset(vcpu, 0, sizeof(*vcpu));
    vgic_init(vcpu->vgic);
    vcpu->vcpu_id = g_next_vcpu_id++;
    vcpu->owner_vm_id = v->vm_id;
    vcpu->state = VCPU_CREATED;
    vcpu->flags = flags;

    const CapHandle cap_h = cap::alloc(*caller.cap_table, CAP_VCPU, vcpu,
                                       RIGHT_VCPU_CONTROL |
                                           RIGHT_VCPU_INSPECT |
                                           RIGHT_DUP);
    if (cap_h == kNullCap) {
        vcpu->state = VCPU_DEAD;
        if (out_error) *out_error = E_OVERFLOW;
        note_error();
        return kNullCap;
    }

    v->vcpus[v->vcpu_count++] = vcpu;
    metric_inc(VM_DEBUG_VCPU_CREATED);
    refresh_vm_state(v);
    if (out_error) *out_error = E_OK;
    return cap_h;
}

SysError set_vcpu_entry(Process& caller, CapHandle vcpu_cap, u64 entry_pc,
                        u64 arg0, u64 arg1) {
    SysError rc = E_OK;
    Vcpu* vcpu = vcpu_from_cap(caller, vcpu_cap, RIGHT_VCPU_CONTROL, &rc);
    if (!vcpu) return rc;
    if (entry_pc == 0) {
        note_error();
        return E_INVALID;
    }

    vcpu->entry_pc = entry_pc;
    vcpu->arg0 = arg0;
    vcpu->arg1 = arg1;
    vcpu->pc = entry_pc;
    vcpu->regs[0] = arg0;
    vcpu->regs[1] = arg1;
    vcpu->state = VCPU_READY;
    metric_inc(VM_DEBUG_VCPU_CONFIGURED);

    Vm* owner = find_vm_by_id(vcpu->owner_vm_id);
    refresh_vm_state(owner);
    return E_OK;
}

SysError inspect_vcpu(Process& caller, CapHandle vcpu_cap, VcpuInfo* out) {
    if (!out) return E_INVALID;
    SysError rc = E_OK;
    Vcpu* vcpu = vcpu_from_cap(caller, vcpu_cap, RIGHT_VCPU_INSPECT, &rc);
    if (!vcpu) return rc;

    VcpuInfo info{};
    info.vcpu_id = vcpu->vcpu_id;
    info.owner_vm_id = vcpu->owner_vm_id;
    info.state = static_cast<u32>(vcpu->state);
    info.entry_pc = vcpu->entry_pc;
    info.arg0 = vcpu->arg0;
    info.arg1 = vcpu->arg1;
    info.run_count = vcpu->run_count;
    info.last_exit_reason = vcpu->last_exit_reason;
    *out = info;
    return E_OK;
}

SysError run_vcpu(Process& caller, CapHandle vcpu_cap, u64 budget_ticks) {
    SysError rc = E_OK;
    Vcpu* vcpu = vcpu_from_cap(caller, vcpu_cap, RIGHT_VCPU_CONTROL, &rc);
    if (!vcpu) return rc;
    if (vcpu->state != VCPU_READY && vcpu->state != VCPU_CONFIGURED) {
        note_error();
        return E_INVALID;
    }

    metric_inc(VM_DEBUG_VCPU_RUN_ATTEMPTS);
    if (vcpu->entry_pc == kLinuxBootProbeEntry || g_boot_el < 2) {
        metric_inc(VM_DEBUG_VCPU_RUN_NOTIMPL);
        vcpu->last_exit_reason = static_cast<u64>(E_NOTIMPL);
        return E_NOTIMPL;
    }

    Vm* owner = find_vm_by_id(vcpu->owner_vm_id);
    if (!owner || !owner->stage2.built || owner->stage2.mapped_pages == 0) {
        note_error();
        return E_INVALID;
    }
    if (!owner->stage2.active) {
        rc = stage2_activate(&owner->stage2);
        if (rc != E_OK) {
            note_error();
            return rc;
        }
    }

    init_el2_state(*vcpu, *owner);
    vcpu->state = VCPU_RUNNING;
    owner->state = VM_RUNNING;

    const u64 max_exits = budget_ticks ? budget_ticks : 1;
    for (u64 exits = 0; exits < max_exits; ++exits) {
        prepare_guest_entry(*vcpu);

        const u64 esr = vm_el2_run(&vcpu->el2);
        ++vcpu->run_count;
        const u64 ec = esr_ec(esr);

        // Physical host IRQ/FIQ/SError routed to EL2 while the guest was active
        // reaches the lower-EL vector with no useful ESR. Treat it as a clean
        // vCPU budget/interrupt exit and let Dango/Ressha decide when to run
        // again. This also prevents host timer IRQs from being reported as
        // guest faults.
        if (esr == 0) {
            sync_vcpu_from_el2(*vcpu);
            vcpu->state = VCPU_READY;
            owner->state = VM_READY;
            vcpu->last_exit_reason = 0;
            metric_inc(VM_DEBUG_VCPU_IRQ_EXITS);
            return E_OK;
        }

        if (ec == kEcDataAbortLower || ec == kEcDataAbortCurrent) {
            const u64 ipa = data_abort_ipa(vcpu->el2);
            if (emulate_mmio(*vcpu, ipa, esr)) continue;
        }

        if (ec == kEcWfx) {
            vcpu->el2.pc += 4;
            sync_vcpu_from_el2(*vcpu);
            vcpu->state = VCPU_READY;
            owner->state = VM_READY;
            vcpu->last_exit_reason = esr;
            metric_inc(VM_DEBUG_VCPU_WFX_EXITS);
            libk::printf("DANGO VCPU EXIT WFX pc=%llx esr=%llx\n",
                         static_cast<unsigned long long>(vcpu->pc),
                         static_cast<unsigned long long>(esr));
            return E_OK;
        }

        if (ec == kEcSysReg) {
            log_sysreg_trap(*vcpu, esr);
        }

        if (ec == kEcInstrAbortLower) {
            const u64 ipa = fault_ipa(vcpu->el2, ec);
            libk::printf("DANGO VM EXIT instr-abort-lower pc=%llx ipa=%llx esr=%llx\n",
                         static_cast<unsigned long long>(vcpu->el2.pc),
                         static_cast<unsigned long long>(ipa),
                         static_cast<unsigned long long>(esr));
        }

        sync_vcpu_from_el2(*vcpu);
        vcpu->state = VCPU_READY;
        owner->state = VM_READY;
        const u64 reason = esr ? esr : kHcrExitUnsupported;
        if (vcpu->last_exit_reason != reason) {
            log_unsupported_exit(*vcpu, *owner, esr, ec);
        }
        vcpu->last_exit_reason = reason;
        metric_inc(VM_DEBUG_VCPU_UNSUPPORTED_EXITS);
        metric_inc(VM_DEBUG_VCPU_RUN_NOTIMPL);
        return E_NOTIMPL;
    }

    sync_vcpu_from_el2(*vcpu);
    vcpu->state = VCPU_READY;
    owner->state = VM_READY;
    vcpu->last_exit_reason = vcpu->el2.exit_esr;
    return E_OK;
}
} // namespace vm
